import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  CalendarCheck2,
  FileText,
  Calendar,
  Bell,
  Megaphone,
  GraduationCap,
  User,
  LogOut,
  Users,
  Building,
  BookOpen,
  School,
  Settings,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  if (!user) return null;

  const adminNav = [
    { name: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
    { name: "Students", href: "/admin/students", icon: Users },
    { name: "Faculty", href: "/admin/faculty", icon: User },
    { name: "Departments", href: "/admin/departments", icon: Building },
    { name: "Subjects", href: "/admin/subjects", icon: BookOpen },
    { name: "Classes", href: "/admin/classes", icon: School },
    { name: "Notices", href: "/admin/notices", icon: Bell },
    { name: "Announcements", href: "/admin/announcements", icon: Megaphone },
    { name: "Timetable", href: "/admin/timetable", icon: Calendar },
    { name: "Marks", href: "/admin/marks", icon: GraduationCap },
  ];

  const facultyNav = [
    { name: "Dashboard", href: "/faculty/dashboard", icon: LayoutDashboard },
    { name: "Attendance", href: "/faculty/attendance", icon: CalendarCheck2 },
    { name: "Assignments", href: "/faculty/assignments", icon: FileText },
    { name: "Marks", href: "/faculty/marks", icon: GraduationCap },
  ];

  const studentNav = [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { name: "Attendance", href: "/attendance", icon: CalendarCheck2 },
    { name: "Assignments", href: "/assignments", icon: FileText },
    { name: "Timetable", href: "/timetable", icon: Calendar },
    { name: "Marks", href: "/marks", icon: GraduationCap },
    { name: "Notices", href: "/notices", icon: Bell },
    { name: "Announcements", href: "/announcements", icon: Megaphone },
    { name: "Profile", href: "/profile", icon: User },
  ];

  let nav = studentNav;
  if (user.role === "admin") nav = adminNav;
  if (user.role === "faculty") nav = facultyNav;

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <aside className="w-64 flex flex-col border-r bg-sidebar text-sidebar-foreground">
        <div className="h-16 flex items-center px-6 border-b border-sidebar-border">
          <div className="font-bold text-lg tracking-tight flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-primary text-primary-foreground flex items-center justify-center text-xs">
              SP
            </div>
            Student Portal
          </div>
        </div>
        <div className="flex-1 overflow-y-auto py-4">
          <nav className="space-y-1 px-3">
            {nav.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                  location === item.href || location.startsWith(`${item.href}/`)
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.name}
              </Link>
            ))}
          </nav>
        </div>
        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center gap-3 px-3 mb-4">
            <div className="w-8 h-8 rounded-full bg-sidebar-accent flex items-center justify-center">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 overflow-hidden">
              <div className="text-sm font-medium truncate">{user.name}</div>
              <div className="text-xs text-sidebar-foreground/60 truncate capitalize">{user.role}</div>
            </div>
          </div>
          <Button variant="outline" className="w-full justify-start text-sidebar-foreground border-sidebar-border bg-sidebar hover:bg-sidebar-accent hover:text-sidebar-accent-foreground" onClick={logout}>
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </aside>
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}