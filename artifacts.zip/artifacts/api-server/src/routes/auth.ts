import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { usersTable, studentsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { signAccessToken, signRefreshToken, verifyRefreshToken } from "../lib/jwt";
import { requireAuth } from "../middlewares/auth";
import {
  LoginBody,
  RegisterBody,
  RefreshTokenBody,
  ForgotPasswordBody,
  ResetPasswordBody,
  ChangePasswordBody,
  UpdateProfileBody,
} from "@workspace/api-zod";

const router = Router();

// POST /auth/login
router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { email, password } = parsed.data;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email.toLowerCase()));
  if (!user) {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }
  const valid = await bcrypt.compare(password, user.password);
  if (!valid) {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }
  const payload = { userId: user.id, role: user.role, email: user.email };
  const accessToken = signAccessToken(payload);
  const refreshToken = signRefreshToken(payload);

  let studentDetails = null;
  let facultyDetails = null;
  if (user.role === "student") {
    const { studentsTable: st } = await import("@workspace/db");
    const [sd] = await db.select().from(st).where(eq(st.userId, user.id));
    if (sd) studentDetails = sd;
  }
  if (user.role === "faculty") {
    const { facultyTable: ft } = await import("@workspace/db");
    const [fd] = await db.select().from(ft).where(eq(ft.userId, user.id));
    if (fd) facultyDetails = fd;
  }

  res.json({
    accessToken,
    refreshToken,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      profilePhoto: user.profilePhoto,
      createdAt: user.createdAt,
      studentDetails,
      facultyDetails,
    },
  });
});

// POST /auth/register (student self-registration)
router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { name, email, password, phone, branch, semester, section, rollNumber } = parsed.data;
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email.toLowerCase()));
  if (existing.length > 0) {
    res.status(400).json({ error: "Email already in use" });
    return;
  }
  const hashed = await bcrypt.hash(password, 10);
  const [user] = await db.insert(usersTable).values({
    name,
    email: email.toLowerCase(),
    password: hashed,
    phone: phone ?? null,
    role: "student",
  }).returning();

  const [student] = await db.insert(studentsTable).values({
    userId: user.id,
    branch: branch ?? "CSE",
    semester: semester ?? "1",
    section: section ?? "A",
    rollNumber: rollNumber ?? `STU${user.id}`,
  }).returning();

  const payload = { userId: user.id, role: user.role, email: user.email };
  const accessToken = signAccessToken(payload);
  const refreshToken = signRefreshToken(payload);

  res.status(201).json({
    accessToken,
    refreshToken,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      profilePhoto: user.profilePhoto,
      createdAt: user.createdAt,
      studentDetails: student,
      facultyDetails: null,
    },
  });
});

// POST /auth/logout
router.post("/auth/logout", (_req, res): void => {
  res.json({ message: "Logged out" });
});

// POST /auth/refresh
router.post("/auth/refresh", async (req, res): Promise<void> => {
  const parsed = RefreshTokenBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "refreshToken required" });
    return;
  }
  try {
    const payload = verifyRefreshToken(parsed.data.refreshToken);
    const accessToken = signAccessToken({ userId: payload.userId, role: payload.role, email: payload.email });
    const newRefreshToken = signRefreshToken({ userId: payload.userId, role: payload.role, email: payload.email });
    res.json({ accessToken, refreshToken: newRefreshToken });
  } catch {
    res.status(401).json({ error: "Invalid refresh token" });
  }
});

// POST /auth/forgot-password
router.post("/auth/forgot-password", async (req, res): Promise<void> => {
  const parsed = ForgotPasswordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, parsed.data.email.toLowerCase()));
  if (!user) {
    res.json({ message: "If that email exists, a reset link was sent" });
    return;
  }
  const token = Math.random().toString(36).slice(2) + Date.now().toString(36);
  const expiry = new Date(Date.now() + 3600000);
  await db.update(usersTable).set({ resetToken: token, resetTokenExpiry: expiry }).where(eq(usersTable.id, user.id));
  req.log.info({ userId: user.id, token }, "Password reset token generated");
  res.json({ message: "If that email exists, a reset link was sent", resetToken: token });
});

// POST /auth/reset-password
router.post("/auth/reset-password", async (req, res): Promise<void> => {
  const parsed = ResetPasswordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { token, password } = parsed.data;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.resetToken, token));
  if (!user || !user.resetTokenExpiry || user.resetTokenExpiry < new Date()) {
    res.status(400).json({ error: "Invalid or expired reset token" });
    return;
  }
  const hashed = await bcrypt.hash(password, 10);
  await db.update(usersTable).set({ password: hashed, resetToken: null, resetTokenExpiry: null }).where(eq(usersTable.id, user.id));
  res.json({ message: "Password reset successfully" });
});

// GET /profile
router.get("/profile", requireAuth, async (req, res): Promise<void> => {
  const userId = req.user!.userId;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  let studentDetails = null;
  let facultyDetails = null;
  if (user.role === "student") {
    const { studentsTable: st } = await import("@workspace/db");
    const [sd] = await db.select().from(st).where(eq(st.userId, user.id));
    if (sd) studentDetails = sd;
  }
  if (user.role === "faculty") {
    const { facultyTable: ft } = await import("@workspace/db");
    const [fd] = await db.select().from(ft).where(eq(ft.userId, user.id));
    if (fd) facultyDetails = fd;
  }
  res.json({
    id: user.id, name: user.name, email: user.email, phone: user.phone,
    role: user.role, profilePhoto: user.profilePhoto,
    createdAt: user.createdAt.toISOString(),
    studentDetails, facultyDetails,
  });
});

// PATCH /profile
router.patch("/profile", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const userId = req.user!.userId;
  const [user] = await db.update(usersTable).set(parsed.data).where(eq(usersTable.id, userId)).returning();
  res.json({ id: user.id, name: user.name, email: user.email, phone: user.phone, role: user.role, profilePhoto: user.profilePhoto, createdAt: user.createdAt.toISOString() });
});

// POST /profile/change-password
router.post("/profile/change-password", requireAuth, async (req, res): Promise<void> => {
  const parsed = ChangePasswordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const userId = req.user!.userId;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  const valid = await bcrypt.compare(parsed.data.currentPassword, user.password);
  if (!valid) {
    res.status(400).json({ error: "Current password is incorrect" });
    return;
  }
  const hashed = await bcrypt.hash(parsed.data.newPassword, 10);
  await db.update(usersTable).set({ password: hashed }).where(eq(usersTable.id, userId));
  res.json({ message: "Password changed" });
});

export default router;
