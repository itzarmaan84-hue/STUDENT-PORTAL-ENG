import { Router } from "express";
import { db } from "@workspace/db";
import {
  usersTable, studentsTable, facultyTable, departmentsTable,
  classesTable, subjectsTable, attendanceTable, assignmentsTable,
  submissionsTable, noticesTable, announcementsTable, activityTable,
  marksTable,
} from "@workspace/db";
import { sql, count, eq, gte, and } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router = Router();

// GET /dashboard/admin-stats
router.get("/dashboard/admin-stats", requireAuth, async (req, res): Promise<void> => {
  const [[{ totalStudents }], [{ totalFaculty }], [{ totalDepartments }], [{ totalClasses }], [{ totalSubjects }]] = await Promise.all([
    db.select({ totalStudents: count() }).from(studentsTable),
    db.select({ totalFaculty: count() }).from(facultyTable),
    db.select({ totalDepartments: count() }).from(departmentsTable),
    db.select({ totalClasses: count() }).from(classesTable),
    db.select({ totalSubjects: count() }).from(subjectsTable),
  ]);

  const [{ totalAtt }] = await db.select({ totalAtt: count() }).from(attendanceTable);
  const presentCount = await db.select({ cnt: count() }).from(attendanceTable).where(eq(attendanceTable.status, "present"));
  const attendanceRate = totalAtt > 0 ? Math.round((presentCount[0].cnt / totalAtt) * 100) : 0;

  const [{ recentAnnouncements }] = await db.select({ recentAnnouncements: count() }).from(announcementsTable);
  const [{ pendingSubmissions }] = await db.select({ pendingSubmissions: count() }).from(submissionsTable);

  res.json({ totalStudents, totalFaculty, totalDepartments, totalClasses, totalSubjects, attendanceRate, recentAnnouncements, pendingSubmissions });
});

// GET /dashboard/student-summary
router.get("/dashboard/student-summary", requireAuth, async (req, res): Promise<void> => {
  const userId = req.user!.userId;
  const [student] = await db.select().from(studentsTable).where(eq(studentsTable.userId, userId));
  if (!student) {
    res.json({ attendancePercentage: 0, upcomingAssignments: 0, unreadNotices: 0, unreadAnnouncements: 0, totalSubjects: 0, averageMarks: 0 });
    return;
  }

  const [total] = await db.select({ cnt: count() }).from(attendanceTable).where(eq(attendanceTable.studentId, student.id));
  const [present] = await db.select({ cnt: count() }).from(attendanceTable).where(
    and(eq(attendanceTable.studentId, student.id), eq(attendanceTable.status, "present"))
  );
  const attendancePercentage = total.cnt > 0 ? Math.round((present.cnt / total.cnt) * 100) : 0;

  const today = new Date().toISOString().split("T")[0];
  const [upcoming] = await db.select({ cnt: count() }).from(assignmentsTable).where(gte(assignmentsTable.dueDate, today));
  const [notices] = await db.select({ cnt: count() }).from(noticesTable);
  const [announcements] = await db.select({ cnt: count() }).from(announcementsTable);
  const [subjects] = await db.select({ cnt: count() }).from(subjectsTable);

  const studentMarks = await db.select().from(marksTable).where(eq(marksTable.studentId, student.id));
  const avgMarks = studentMarks.length > 0
    ? Math.round(studentMarks.reduce((sum, m) => sum + ((m.internal1 ?? 0) + (m.internal2 ?? 0) + (m.assignmentMarks ?? 0)) / 3, 0) / studentMarks.length)
    : 0;

  res.json({
    attendancePercentage,
    upcomingAssignments: upcoming.cnt,
    unreadNotices: notices.cnt,
    unreadAnnouncements: announcements.cnt,
    totalSubjects: subjects.cnt,
    averageMarks: avgMarks,
  });
});

// GET /dashboard/faculty-summary
router.get("/dashboard/faculty-summary", requireAuth, async (req, res): Promise<void> => {
  const userId = req.user!.userId;
  const [faculty] = await db.select().from(facultyTable).where(eq(facultyTable.userId, userId));
  if (!faculty) {
    res.json({ assignedClasses: 0, totalStudents: 0, pendingSubmissions: 0, assignmentsCreated: 0, averageAttendance: 0 });
    return;
  }

  const timetableEntries = await db.execute(sql`SELECT DISTINCT class_id FROM timetable WHERE faculty_id = ${faculty.id}`);
  const assignedClasses = timetableEntries.rows.length;

  const [totalStudents] = await db.select({ cnt: count() }).from(studentsTable);
  const [assignmentsCreated] = await db.select({ cnt: count() }).from(assignmentsTable).where(eq(assignmentsTable.facultyId, faculty.id));
  const [pending] = await db.select({ cnt: count() }).from(submissionsTable);

  const [totalAtt] = await db.select({ cnt: count() }).from(attendanceTable).where(eq(attendanceTable.facultyId, faculty.id));
  const [presentAtt] = await db.select({ cnt: count() }).from(attendanceTable).where(
    and(eq(attendanceTable.facultyId, faculty.id), eq(attendanceTable.status, "present"))
  );
  const averageAttendance = totalAtt.cnt > 0 ? Math.round((presentAtt.cnt / totalAtt.cnt) * 100) : 0;

  res.json({
    assignedClasses,
    totalStudents: totalStudents.cnt,
    pendingSubmissions: pending.cnt,
    assignmentsCreated: assignmentsCreated.cnt,
    averageAttendance,
  });
});

// GET /dashboard/recent-activity
router.get("/dashboard/recent-activity", requireAuth, async (req, res): Promise<void> => {
  const activities = await db.select().from(activityTable).orderBy(sql`created_at DESC`).limit(20);
  res.json(activities.map(a => ({
    id: a.id,
    type: a.type,
    message: a.message,
    actor: a.actor,
    createdAt: a.createdAt.toISOString(),
  })));
});

export default router;
