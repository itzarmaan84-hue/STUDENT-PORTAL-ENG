import { useState } from "react";
import { useListAssignments, useSubmitAssignment, getListAssignmentsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { CalendarClock, CheckCircle } from "lucide-react";

export default function StudentAssignments() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: assignments, isLoading } = useListAssignments({}, { query: { queryKey: getListAssignmentsQueryKey({}) } });
  const submitMutation = useSubmitAssignment();
  const [selected, setSelected] = useState<number | null>(null);
  const [fileUrl, setFileUrl] = useState("");
  const [notes, setNotes] = useState("");

  const handleSubmit = () => {
    if (!selected) return;
    submitMutation.mutate({ id: selected, data: { fileUrl: fileUrl || undefined, notes: notes || undefined } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAssignmentsQueryKey({}) });
        toast({ title: "Assignment submitted" });
        setSelected(null); setFileUrl(""); setNotes("");
      },
      onError: () => toast({ title: "Submission failed", variant: "destructive" }),
    });
  };

  const isOverdue = (due: string) => new Date(due) < new Date();

  return (
    <div className="p-8" data-testid="page-assignments">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Assignments</h1>
        <p className="text-muted-foreground text-sm">View and submit your assignments</p>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
        </div>
      ) : assignments && assignments.length > 0 ? (
        <div className="space-y-3">
          {assignments.map(a => (
            <Card key={a.id} data-testid={`assignment-card-${a.id}`}>
              <CardContent className="pt-5 pb-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{a.title}</h3>
                      {a.mySubmission && <Badge variant="default" className="text-xs"><CheckCircle className="w-3 h-3 mr-1" />Submitted</Badge>}
                      {!a.mySubmission && isOverdue(a.dueDate) && <Badge variant="destructive" className="text-xs">Overdue</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{a.description}</p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><CalendarClock className="w-3 h-3" />Due: {new Date(a.dueDate).toLocaleDateString()}</span>
                      {a.subjectName && <span>Subject: {a.subjectName}</span>}
                      {a.facultyName && <span>Faculty: {a.facultyName}</span>}
                    </div>
                  </div>
                  {!a.mySubmission && (
                    <Button size="sm" onClick={() => setSelected(a.id)} data-testid={`button-submit-${a.id}`}>
                      Submit
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-muted-foreground">
          <FileText className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>No assignments yet</p>
        </div>
      )}

      <Dialog open={!!selected} onOpenChange={v => !v && setSelected(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Submit Assignment</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label className="text-sm font-medium block mb-1.5">Submission URL / Link</label>
              <Input data-testid="input-file-url" placeholder="https://..." value={fileUrl} onChange={e => setFileUrl(e.target.value)} />
            </div>
            <div>
              <label className="text-sm font-medium block mb-1.5">Notes</label>
              <Textarea data-testid="textarea-notes" placeholder="Any notes for the faculty..." value={notes} onChange={e => setNotes(e.target.value)} rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelected(null)}>Cancel</Button>
            <Button data-testid="button-confirm-submit" onClick={handleSubmit} disabled={submitMutation.isPending}>
              {submitMutation.isPending ? "Submitting..." : "Submit"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function FileText({ className }: { className?: string }) {
  return <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14,2 14,8 20,8"/></svg>;
}
