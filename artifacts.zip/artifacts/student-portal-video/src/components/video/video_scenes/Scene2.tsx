import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video/animations';

export function Scene2() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 300),
      setTimeout(() => setPhase(2), 800),
      setTimeout(() => setPhase(3), 1200),
      setTimeout(() => setPhase(4), 1600),
      setTimeout(() => setPhase(5), 3200),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, []);

  return (
    <motion.div className="absolute inset-0 flex items-center justify-start px-[10vw]"
      {...sceneTransitions.slideLeft}>
      
      <div className="absolute right-0 top-0 bottom-0 w-1/2 z-0">
        <img src={`${import.meta.env.BASE_URL}images/tech-bg.jpg`} className="w-full h-full object-cover opacity-40 mix-blend-luminosity" alt="" />
        <div className="absolute inset-0 bg-gradient-to-r from-bg-dark to-transparent" />
      </div>

      <div className="relative z-10 w-1/2">
        <motion.div 
          className="text-accent text-[1.5vw] font-mono mb-4"
          initial={{ opacity: 0, x: -20 }}
          animate={phase >= 1 ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
        >
          // ROLE: ADMIN
        </motion.div>

        <motion.h2 
          className="text-[6vw] font-display font-bold leading-tight mb-8"
          initial={{ opacity: 0, y: 40 }}
          animate={phase >= 2 ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
        >
          CONTROL THE<br />ECOSYSTEM
        </motion.h2>

        <div className="flex flex-col gap-4">
          {['Manage Students & Faculty', 'Organize Timetables', 'System Announcements'].map((text, i) => (
            <motion.div 
              key={i}
              className="flex items-center gap-4 text-[2vw] text-text-secondary"
              initial={{ opacity: 0, x: -20 }}
              animate={phase >= 3 + i ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
              transition={{ delay: i * 0.15 }}
            >
              <div className="w-3 h-3 bg-accent" />
              {text}
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
