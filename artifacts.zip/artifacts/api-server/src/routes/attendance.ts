import { Router } from "express";
import { db } from "@workspace/db";
import { attendanceTable, studentsTable, subjectsTable, usersTable } from "@workspace/db";
import { eq, and, SQL, count } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";
import {
  ListAttendanceQueryParams, MarkAttendanceBody,
  UpdateAttendanceParams, UpdateAttendanceBody,
  GetAttendanceReportQueryParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/attendance/report", requireAuth, async (req, res): Promise<void> => {
  const params = GetAttendanceReportQueryParams.safeParse(req.query);
  const filters: SQL[] = [];
  if (params.success) {
    if (params.data.studentId) filters.push(eq(attendanceTable.studentId, params.data.studentId));
    if (params.data.subjectId) filters.push(eq(attendanceTable.subjectId, params.data.subjectId));
  }
  // Students can only see their own attendance
  if (req.user?.role === "student") {
    const [student] = await db.select().from(studentsTable).where(eq(studentsTable.userId, req.user.userId));
    if (student) filters.push(eq(attendanceTable.studentId, student.id));
  }

  const rows = await db.select({
    studentId: attendanceTable.studentId,
    subjectId: attendanceTable.subjectId,
    status: attendanceTable.status,
    studentName: usersTable.name,
    subjectName: subjectsTable.name,
  }).from(attendanceTable)
    .leftJoin(studentsTable, eq(attendanceTable.studentId, studentsTable.id))
    .leftJoin(usersTable, eq(studentsTable.userId, usersTable.id))
    .leftJoin(subjectsTable, eq(attendanceTable.subjectId, subjectsTable.id))
    .where(filters.length > 0 ? and(...filters) : undefined);

  type Key = `${number}_${number}`;
  const grouped: Record<Key, { studentId: number; subjectId: number; studentName: string; subjectName: string; present: number; absent: number; late: number }> = {};
  for (const r of rows) {
    const key: Key = `${r.studentId}_${r.subjectId}`;
    if (!grouped[key]) {
      grouped[key] = { studentId: r.studentId, subjectId: r.subjectId, studentName: r.studentName ?? "", subjectName: r.subjectName ?? "", present: 0, absent: 0, late: 0 };
    }
    if (r.status === "present") grouped[key].present++;
    else if (r.status === "absent") grouped[key].absent++;
    else if (r.status === "late") grouped[key].late++;
  }

  res.json(Object.values(grouped).map(g => ({
    ...g,
    totalClasses: g.present + g.absent + g.late,
    percentage: g.present + g.absent + g.late > 0 ? Math.round((g.present / (g.present + g.absent + g.late)) * 100) : 0,
  })));
});

router.get("/attendance", requireAuth, async (req, res): Promise<void> => {
  const params = ListAttendanceQueryParams.safeParse(req.query);
  const filters: SQL[] = [];
  if (params.success) {
    if (params.data.studentId) filters.push(eq(attendanceTable.studentId, params.data.studentId));
    if (params.data.subjectId) filters.push(eq(attendanceTable.subjectId, params.data.subjectId));
    if (params.data.date) filters.push(eq(attendanceTable.date, params.data.date));
  }
  const rows = await db.select({
    id: attendanceTable.id, studentId: attendanceTable.studentId,
    subjectId: attendanceTable.subjectId, facultyId: attendanceTable.facultyId,
    date: attendanceTable.date, status: attendanceTable.status,
    studentName: usersTable.name, subjectName: subjectsTable.name,
  }).from(attendanceTable)
    .leftJoin(studentsTable, eq(attendanceTable.studentId, studentsTable.id))
    .leftJoin(usersTable, eq(studentsTable.userId, usersTable.id))
    .leftJoin(subjectsTable, eq(attendanceTable.subjectId, subjectsTable.id))
    .where(filters.length > 0 ? and(...filters) : undefined);
  res.json(rows);
});

router.post("/attendance", requireAuth, async (req, res): Promise<void> => {
  const parsed = MarkAttendanceBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { subjectId, facultyId, date, records } = parsed.data;
  const inserted = await db.insert(attendanceTable).values(
    records.map(r => ({ studentId: r.studentId, subjectId, facultyId: facultyId ?? null, date, status: r.status as "present" | "absent" | "late" }))
  ).returning();
  res.status(201).json(inserted);
});

router.patch("/attendance/:id", requireAuth, async (req, res): Promise<void> => {
  const params = UpdateAttendanceParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateAttendanceBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [att] = await db.update(attendanceTable).set({ status: parsed.data.status as "present" | "absent" | "late" }).where(eq(attendanceTable.id, params.data.id)).returning();
  if (!att) { res.status(404).json({ error: "Attendance record not found" }); return; }
  res.json({ ...att, studentName: null, subjectName: null });
});

export default router;
