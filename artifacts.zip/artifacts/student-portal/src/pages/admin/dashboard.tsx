import { useGetAdminStats, useGetRecentActivity, getGetAdminStatsQueryKey, getGetRecentActivityQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, User, Building, School, BookOpen, CalendarCheck2, Bell, FileText } from "lucide-react";

function StatCard({ title, value, icon: Icon, color = "primary" }: { title: string; value: string | number; icon: React.ElementType; color?: string }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-3xl font-bold mt-1" data-testid={`stat-${title.toLowerCase().replace(/\s+/g, "-")}`}>{value}</p>
          </div>
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Icon className="w-5 h-5 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function AdminDashboard() {
  const { data: stats, isLoading } = useGetAdminStats({ query: { queryKey: getGetAdminStatsQueryKey() } });
  const { data: activity } = useGetRecentActivity({ query: { queryKey: getGetRecentActivityQueryKey() } });

  return (
    <div className="p-8" data-testid="page-admin-dashboard">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground text-sm">Institution overview and statistics</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard title="Total Students" value={stats?.totalStudents ?? 0} icon={Users} />
          <StatCard title="Total Faculty" value={stats?.totalFaculty ?? 0} icon={User} />
          <StatCard title="Departments" value={stats?.totalDepartments ?? 0} icon={Building} />
          <StatCard title="Classes" value={stats?.totalClasses ?? 0} icon={School} />
          <StatCard title="Subjects" value={stats?.totalSubjects ?? 0} icon={BookOpen} />
          <StatCard title="Attendance Rate" value={`${stats?.attendanceRate ?? 0}%`} icon={CalendarCheck2} />
          <StatCard title="Announcements" value={stats?.recentAnnouncements ?? 0} icon={Bell} />
          <StatCard title="Submissions" value={stats?.pendingSubmissions ?? 0} icon={FileText} />
        </div>
      )}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          {activity && activity.length > 0 ? (
            <div className="space-y-3">
              {activity.slice(0, 10).map(a => (
                <div key={a.id} className="flex items-start gap-3 text-sm" data-testid={`activity-${a.id}`}>
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                  <div>
                    <span>{a.message}</span>
                    {a.actor && <span className="text-muted-foreground"> — {a.actor}</span>}
                    <p className="text-xs text-muted-foreground mt-0.5">{new Date(a.createdAt).toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No recent activity</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
