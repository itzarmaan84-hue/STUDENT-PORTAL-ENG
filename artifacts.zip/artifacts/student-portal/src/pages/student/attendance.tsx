import { useGetAttendanceReport, getGetAttendanceReportQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function StudentAttendance() {
  const { data: report, isLoading } = useGetAttendanceReport({}, { query: { queryKey: getGetAttendanceReportQueryKey({}) } });

  const overall = report && report.length > 0
    ? Math.round(report.reduce((sum, r) => sum + r.percentage, 0) / report.length)
    : 0;

  return (
    <div className="p-8" data-testid="page-attendance">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Attendance</h1>
        <p className="text-muted-foreground text-sm">Your attendance records by subject</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Overall Attendance</p>
            <p className="text-3xl font-bold mt-1" data-testid="stat-overall-attendance">{overall}%</p>
            <Progress value={overall} className="mt-3 h-2" />
            <p className={`text-xs mt-2 ${overall >= 75 ? "text-green-600" : "text-destructive"}`}>
              {overall >= 75 ? "Satisfactory" : "Below required 75%"}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Total Classes</p>
            <p className="text-3xl font-bold mt-1">{report?.reduce((sum, r) => sum + r.totalClasses, 0) ?? 0}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">Present Classes</p>
            <p className="text-3xl font-bold mt-1">{report?.reduce((sum, r) => sum + r.present, 0) ?? 0}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Subject-wise Attendance</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12" />)}
            </div>
          ) : report && report.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Subject</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead className="text-right">Present</TableHead>
                  <TableHead className="text-right">Absent</TableHead>
                  <TableHead className="text-right">Late</TableHead>
                  <TableHead className="text-right">Percentage</TableHead>
                  <TableHead className="text-right">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {report.map(r => (
                  <TableRow key={`${r.studentId}_${r.subjectId}`} data-testid={`attendance-row-${r.subjectId}`}>
                    <TableCell className="font-medium">{r.subjectName}</TableCell>
                    <TableCell className="text-right">{r.totalClasses}</TableCell>
                    <TableCell className="text-right text-green-600">{r.present}</TableCell>
                    <TableCell className="text-right text-destructive">{r.absent}</TableCell>
                    <TableCell className="text-right text-yellow-600">{r.late}</TableCell>
                    <TableCell className="text-right font-semibold">{r.percentage}%</TableCell>
                    <TableCell className="text-right">
                      <Badge variant={r.percentage >= 75 ? "default" : "destructive"}>
                        {r.percentage >= 75 ? "OK" : "Low"}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-sm text-muted-foreground py-4 text-center">No attendance records yet</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
