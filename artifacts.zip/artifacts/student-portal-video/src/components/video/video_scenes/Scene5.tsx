import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video/animations';

export function Scene5() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 400),
      setTimeout(() => setPhase(2), 1200),
      setTimeout(() => setPhase(3), 3000),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, []);

  return (
    <motion.div className="absolute inset-0 flex items-center justify-center"
      {...sceneTransitions.zoomThrough}>
      
      <div className="absolute inset-0 z-0 bg-gradient-to-br from-bg-dark via-primary to-bg-dark opacity-80" />

      <div className="relative z-10 text-center">
        <motion.div
          initial={{ scale: 2, opacity: 0, filter: 'blur(20px)' }}
          animate={phase >= 1 ? { scale: 1, opacity: 1, filter: 'blur(0px)' } : { scale: 2, opacity: 0, filter: 'blur(20px)' }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center"
        >
          <div className="flex items-center gap-6 mb-8">
            <div className="w-16 h-16 bg-accent rounded-xl rotate-45 flex items-center justify-center">
              <div className="w-8 h-8 bg-bg-dark rounded-full" />
            </div>
            <h1 className="text-[6vw] font-display font-black tracking-tighter">
              STUDENT<span className="text-accent">PORTAL</span>
            </h1>
          </div>
          
          <motion.p 
            className="text-[2vw] text-text-secondary font-mono tracking-widest uppercase"
            initial={{ opacity: 0, y: 20 }}
            animate={phase >= 2 ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.8 }}
          >
            MODERN ACADEMIC INFRASTRUCTURE
          </motion.p>
        </motion.div>
      </div>

    </motion.div>
  );
}
