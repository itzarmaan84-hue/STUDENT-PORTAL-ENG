import { useState } from "react";
import { useListAssignments, useCreateAssignment, useDeleteAssignment, useListSubmissions, useListSubjects, getListAssignmentsQueryKey, getListSubjectsQueryKey, getListSubmissionsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Eye } from "lucide-react";

const schema = z.object({
  title: z.string().min(1, "Title required"),
  description: z.string().min(1, "Description required"),
  dueDate: z.string().min(1, "Due date required"),
  subjectId: z.string().min(1, "Subject required"),
});

export default function FacultyAssignments() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [createOpen, setCreateOpen] = useState(false);
  const [viewSubs, setViewSubs] = useState<number | null>(null);

  const { data: assignments, isLoading } = useListAssignments({}, { query: { queryKey: getListAssignmentsQueryKey({}) } });
  const { data: subjects } = useListSubjects({}, { query: { queryKey: getListSubjectsQueryKey({}) } });
  const { data: submissions } = useListSubmissions(viewSubs!, { query: { enabled: !!viewSubs, queryKey: getListSubmissionsQueryKey(viewSubs!) } });
  const createMutation = useCreateAssignment();
  const deleteMutation = useDeleteAssignment();

  const form = useForm({ resolver: zodResolver(schema), defaultValues: { title: "", description: "", dueDate: "", subjectId: "" } });

  const onSubmit = (data: z.infer<typeof schema>) => {
    createMutation.mutate({ data: { title: data.title, description: data.description, dueDate: data.dueDate, subjectId: parseInt(data.subjectId) } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAssignmentsQueryKey({}) });
        toast({ title: "Assignment created" });
        setCreateOpen(false);
        form.reset();
      },
      onError: () => toast({ title: "Failed to create", variant: "destructive" }),
    });
  };

  const handleDelete = (id: number) => {
    deleteMutation.mutate({ id }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListAssignmentsQueryKey({}) }); toast({ title: "Deleted" }); },
      onError: () => toast({ title: "Delete failed", variant: "destructive" }),
    });
  };

  return (
    <div className="p-8" data-testid="page-faculty-assignments">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Assignments</h1>
          <p className="text-muted-foreground text-sm">Create and manage assignments</p>
        </div>
        <Button onClick={() => setCreateOpen(true)} data-testid="button-create-assignment">
          <Plus className="w-4 h-4 mr-1" />Create
        </Button>
      </div>

      <Card>
        <CardContent className="pt-4">
          {assignments && assignments.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead className="text-right">Submissions</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {assignments.map(a => (
                  <TableRow key={a.id} data-testid={`assignment-row-${a.id}`}>
                    <TableCell className="font-medium">{a.title}</TableCell>
                    <TableCell>{a.subjectName ?? "—"}</TableCell>
                    <TableCell>
                      <span className={new Date(a.dueDate) < new Date() ? "text-destructive" : ""}>{new Date(a.dueDate).toLocaleDateString()}</span>
                    </TableCell>
                    <TableCell className="text-right">{a.submissionCount ?? 0}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button size="sm" variant="outline" onClick={() => setViewSubs(a.id)} data-testid={`button-view-subs-${a.id}`}>
                          <Eye className="w-3 h-3 mr-1" />Submissions
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => handleDelete(a.id)} data-testid={`button-delete-${a.id}`}>
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-sm text-muted-foreground py-4 text-center">No assignments yet. Create one to get started.</p>
          )}
        </CardContent>
      </Card>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create Assignment</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="title" render={({ field }) => (
                <FormItem><FormLabel>Title</FormLabel><FormControl><Input data-testid="input-title" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="description" render={({ field }) => (
                <FormItem><FormLabel>Description</FormLabel><FormControl><Textarea data-testid="input-description" rows={3} {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="dueDate" render={({ field }) => (
                  <FormItem><FormLabel>Due Date</FormLabel><FormControl><Input type="date" data-testid="input-due-date" {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="subjectId" render={({ field }) => (
                  <FormItem><FormLabel>Subject</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger data-testid="select-subject"><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                      <SelectContent>{subjects?.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}</SelectContent>
                    </Select>
                  <FormMessage /></FormItem>
                )} />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
                <Button type="submit" data-testid="button-confirm-create" disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Creating..." : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!viewSubs} onOpenChange={v => !v && setViewSubs(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle>Submissions</DialogTitle></DialogHeader>
          {submissions && submissions.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Submitted On</TableHead>
                  <TableHead>Notes</TableHead>
                  <TableHead>Link</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {submissions.map(s => (
                  <TableRow key={s.id}>
                    <TableCell>{s.studentName ?? "—"}</TableCell>
                    <TableCell>{new Date(s.submissionDate).toLocaleDateString()}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{s.notes ?? "—"}</TableCell>
                    <TableCell>{s.fileUrl ? <a href={s.fileUrl} target="_blank" rel="noopener noreferrer" className="text-primary text-sm hover:underline">View</a> : "—"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : <p className="text-sm text-muted-foreground py-4 text-center">No submissions yet</p>}
        </DialogContent>
      </Dialog>
    </div>
  );
}
