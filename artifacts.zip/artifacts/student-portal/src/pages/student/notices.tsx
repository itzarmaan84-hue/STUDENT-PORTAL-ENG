import { useListNotices, getListNoticesQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Bell } from "lucide-react";

export default function StudentNotices() {
  const { data: notices, isLoading } = useListNotices({ query: { queryKey: getListNoticesQueryKey() } });

  return (
    <div className="p-8" data-testid="page-notices">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Notice Board</h1>
        <p className="text-muted-foreground text-sm">Official notices and circulars</p>
      </div>

      {isLoading ? (
        <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)}</div>
      ) : notices && notices.length > 0 ? (
        <div className="space-y-3">
          {[...notices].reverse().map(n => (
            <Card key={n.id} data-testid={`notice-card-${n.id}`}>
              <CardContent className="pt-5 pb-4">
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                    <Bell className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">{n.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{n.description}</p>
                    {n.attachment && (
                      <a href={n.attachment} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline mt-2 block">View attachment</a>
                    )}
                    <p className="text-xs text-muted-foreground mt-2">{new Date(n.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-muted-foreground">
          <Bell className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>No notices yet</p>
        </div>
      )}
    </div>
  );
}
