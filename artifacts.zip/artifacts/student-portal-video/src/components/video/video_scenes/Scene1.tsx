import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video/animations';

export function Scene1() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 200),
      setTimeout(() => setPhase(2), 800),
      setTimeout(() => setPhase(3), 1500),
      setTimeout(() => setPhase(4), 2800),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, []);

  return (
    <motion.div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40"
      {...sceneTransitions.clipPolygon}>
      
      <div className="absolute inset-0 z-0">
        <img src={`${import.meta.env.BASE_URL}images/campus.jpg`} className="w-full h-full object-cover opacity-30 mix-blend-overlay" alt="" />
      </div>

      <div className="relative z-10 flex flex-col items-center">
        {phase >= 1 && (
          <motion.div 
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
            className="w-24 h-24 rounded-2xl bg-accent flex items-center justify-center mb-8 rotate-12 shadow-2xl"
          >
            <div className="w-12 h-12 border-4 border-bg-dark rounded-full" />
          </motion.div>
        )}

        <motion.h1 
          className="text-[8vw] font-display font-bold tracking-tighter text-white leading-none text-center"
          initial={{ y: 50, opacity: 0 }}
          animate={phase >= 2 ? { y: 0, opacity: 1 } : { y: 50, opacity: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          STUDENT<br />
          <span className="text-accent">PORTAL</span>
        </motion.h1>

        <motion.p 
          className="text-[2vw] text-text-secondary mt-6 font-mono tracking-widest uppercase"
          initial={{ opacity: 0, letterSpacing: "0px" }}
          animate={phase >= 3 ? { opacity: 1, letterSpacing: "8px" } : { opacity: 0, letterSpacing: "0px" }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          ACADEMIC MANAGEMENT SYSTEM
        </motion.p>
      </div>

    </motion.div>
  );
}
