import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useGetProfile, useUpdateProfile, useChangePassword, getGetProfileQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { User } from "lucide-react";

const profileSchema = z.object({ name: z.string().min(2), phone: z.string().optional() });
const pwSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(6, "Min 6 characters"),
  confirm: z.string(),
}).refine(d => d.newPassword === d.confirm, { message: "Passwords don't match", path: ["confirm"] });

export default function ProfilePage() {
  const { user: authUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<"profile"|"password">("profile");

  const { data: profile, isLoading } = useGetProfile({ query: { queryKey: getGetProfileQueryKey() } });
  const updateMutation = useUpdateProfile();
  const changePwMutation = useChangePassword();

  const profileForm = useForm({ resolver: zodResolver(profileSchema), defaultValues: { name: profile?.name ?? "", phone: profile?.phone ?? "" } });
  const pwForm = useForm({ resolver: zodResolver(pwSchema), defaultValues: { currentPassword: "", newPassword: "", confirm: "" } });

  const onProfileSubmit = (data: z.infer<typeof profileSchema>) => {
    updateMutation.mutate({ data }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetProfileQueryKey() });
        toast({ title: "Profile updated" });
      },
      onError: () => toast({ title: "Failed to update", variant: "destructive" }),
    });
  };

  const onPasswordSubmit = (data: z.infer<typeof pwSchema>) => {
    changePwMutation.mutate({ data: { currentPassword: data.currentPassword, newPassword: data.newPassword } }, {
      onSuccess: () => { toast({ title: "Password changed" }); pwForm.reset(); },
      onError: () => toast({ title: "Failed to change password", variant: "destructive" }),
    });
  };

  if (isLoading) return (
    <div className="p-8 space-y-4">
      <Skeleton className="h-8 w-48" />
      <Skeleton className="h-32 w-full" />
    </div>
  );

  return (
    <div className="p-8 max-w-2xl" data-testid="page-profile">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Profile</h1>
        <p className="text-muted-foreground text-sm">Manage your account information</p>
      </div>

      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <User className="w-8 h-8" />
            </div>
            <div>
              <div className="text-xl font-semibold">{profile?.name}</div>
              <div className="text-muted-foreground text-sm">{profile?.email}</div>
              <Badge variant="secondary" className="mt-1 capitalize">{profile?.role}</Badge>
            </div>
          </div>
          {profile?.studentDetails && (
            <div className="mt-4 grid grid-cols-3 gap-4 pt-4 border-t text-sm">
              <div><div className="text-muted-foreground">Branch</div><div className="font-medium">{profile.studentDetails.branch}</div></div>
              <div><div className="text-muted-foreground">Semester</div><div className="font-medium">Sem {profile.studentDetails.semester}</div></div>
              <div><div className="text-muted-foreground">Section</div><div className="font-medium">{profile.studentDetails.section}</div></div>
              <div><div className="text-muted-foreground">Roll Number</div><div className="font-medium">{profile.studentDetails.rollNumber}</div></div>
            </div>
          )}
          {profile?.facultyDetails && (
            <div className="mt-4 grid grid-cols-2 gap-4 pt-4 border-t text-sm">
              <div><div className="text-muted-foreground">Department</div><div className="font-medium">{profile.facultyDetails.department}</div></div>
              <div><div className="text-muted-foreground">Designation</div><div className="font-medium">{profile.facultyDetails.designation}</div></div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex gap-1 mb-6">
        <Button variant={tab === "profile" ? "default" : "ghost"} size="sm" onClick={() => setTab("profile")}>Edit Profile</Button>
        <Button variant={tab === "password" ? "default" : "ghost"} size="sm" onClick={() => setTab("password")}>Change Password</Button>
      </div>

      {tab === "profile" && (
        <Card>
          <CardHeader><CardTitle className="text-base">Edit Profile</CardTitle></CardHeader>
          <CardContent>
            <Form {...profileForm}>
              <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-4">
                <FormField control={profileForm.control} name="name" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl><Input data-testid="input-name" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={profileForm.control} name="phone" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone</FormLabel>
                    <FormControl><Input data-testid="input-phone" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <Button data-testid="button-save" type="submit" disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Saving..." : "Save changes"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}

      {tab === "password" && (
        <Card>
          <CardHeader><CardTitle className="text-base">Change Password</CardTitle></CardHeader>
          <CardContent>
            <Form {...pwForm}>
              <form onSubmit={pwForm.handleSubmit(onPasswordSubmit)} className="space-y-4">
                <FormField control={pwForm.control} name="currentPassword" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current Password</FormLabel>
                    <FormControl><Input data-testid="input-current-password" type="password" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={pwForm.control} name="newPassword" render={({ field }) => (
                  <FormItem>
                    <FormLabel>New Password</FormLabel>
                    <FormControl><Input data-testid="input-new-password" type="password" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={pwForm.control} name="confirm" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Confirm New Password</FormLabel>
                    <FormControl><Input data-testid="input-confirm-password" type="password" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <Button data-testid="button-change-password" type="submit" disabled={changePwMutation.isPending}>
                  {changePwMutation.isPending ? "Changing..." : "Change password"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
