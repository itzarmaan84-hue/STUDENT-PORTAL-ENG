import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { usersTable, facultyTable } from "@workspace/db";
import { eq, ilike, and, SQL } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";
import {
  ListFacultyQueryParams,
  CreateFacultyBody,
  GetFacultyParams,
  UpdateFacultyParams,
  UpdateFacultyBody,
  DeleteFacultyParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/faculty", requireAuth, async (req, res): Promise<void> => {
  const params = ListFacultyQueryParams.safeParse(req.query);
  const filters: SQL[] = [];
  if (params.success && params.data.department) {
    filters.push(ilike(facultyTable.department, `%${params.data.department}%`));
  }
  const rows = await db.select({
    id: facultyTable.id, userId: facultyTable.userId,
    department: facultyTable.department, designation: facultyTable.designation,
    createdAt: facultyTable.createdAt,
    name: usersTable.name, email: usersTable.email, phone: usersTable.phone, profilePhoto: usersTable.profilePhoto,
  }).from(facultyTable).innerJoin(usersTable, eq(facultyTable.userId, usersTable.id))
    .where(filters.length > 0 ? and(...filters) : undefined);

  if (params.success && params.data.search) {
    const s = params.data.search.toLowerCase();
    res.json(rows.filter(r => r.name.toLowerCase().includes(s) || r.email.toLowerCase().includes(s)).map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
    return;
  }
  res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/faculty", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const parsed = CreateFacultyBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { name, email, password, phone, department, designation } = parsed.data;
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email.toLowerCase()));
  if (existing.length > 0) { res.status(400).json({ error: "Email already in use" }); return; }
  const hashed = await bcrypt.hash(password, 10);
  const [user] = await db.insert(usersTable).values({ name, email: email.toLowerCase(), password: hashed, phone, role: "faculty" }).returning();
  const [faculty] = await db.insert(facultyTable).values({ userId: user.id, department, designation }).returning();
  res.status(201).json({ ...faculty, name: user.name, email: user.email, phone: user.phone, profilePhoto: user.profilePhoto, createdAt: faculty.createdAt.toISOString() });
});

router.get("/faculty/:id", requireAuth, async (req, res): Promise<void> => {
  const params = GetFacultyParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [row] = await db.select({
    id: facultyTable.id, userId: facultyTable.userId,
    department: facultyTable.department, designation: facultyTable.designation,
    createdAt: facultyTable.createdAt,
    name: usersTable.name, email: usersTable.email, phone: usersTable.phone, profilePhoto: usersTable.profilePhoto,
  }).from(facultyTable).innerJoin(usersTable, eq(facultyTable.userId, usersTable.id)).where(eq(facultyTable.id, params.data.id));
  if (!row) { res.status(404).json({ error: "Faculty not found" }); return; }
  res.json({ ...row, createdAt: row.createdAt.toISOString() });
});

router.patch("/faculty/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = UpdateFacultyParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateFacultyBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { name, phone, ...facultyFields } = parsed.data;
  const [fac] = await db.select().from(facultyTable).where(eq(facultyTable.id, params.data.id));
  if (!fac) { res.status(404).json({ error: "Faculty not found" }); return; }
  if (name || phone) await db.update(usersTable).set({ ...(name ? { name } : {}), ...(phone ? { phone } : {}) }).where(eq(usersTable.id, fac.userId));
  if (Object.keys(facultyFields).length > 0) await db.update(facultyTable).set(facultyFields).where(eq(facultyTable.id, params.data.id));
  const [updated] = await db.select({
    id: facultyTable.id, userId: facultyTable.userId, department: facultyTable.department, designation: facultyTable.designation,
    createdAt: facultyTable.createdAt, name: usersTable.name, email: usersTable.email, phone: usersTable.phone, profilePhoto: usersTable.profilePhoto,
  }).from(facultyTable).innerJoin(usersTable, eq(facultyTable.userId, usersTable.id)).where(eq(facultyTable.id, params.data.id));
  res.json({ ...updated, createdAt: updated.createdAt.toISOString() });
});

router.delete("/faculty/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = DeleteFacultyParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [fac] = await db.select().from(facultyTable).where(eq(facultyTable.id, params.data.id));
  if (!fac) { res.status(404).json({ error: "Faculty not found" }); return; }
  await db.delete(usersTable).where(eq(usersTable.id, fac.userId));
  res.sendStatus(204);
});

export default router;
