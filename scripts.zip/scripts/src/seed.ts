import "dotenv/config";
import { db } from "@workspace/db";
import {
  usersTable, studentsTable, facultyTable, departmentsTable,
  subjectsTable, classesTable, announcementsTable, noticesTable,
  activityTable,
} from "@workspace/db";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";

async function seed() {
  console.log("Seeding database...");

  // Admin user
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, "admin@portal.edu"));
  if (existing.length === 0) {
    const hashed = await bcrypt.hash("admin123", 10);
    await db.insert(usersTable).values({
      name: "Admin User",
      email: "admin@portal.edu",
      password: hashed,
      role: "admin",
      phone: "9000000000",
    });
    console.log("Created admin: admin@portal.edu / admin123");
  } else {
    console.log("Admin already exists");
  }

  // Departments
  const depts = [
    { name: "Computer Science & Engineering", code: "CSE" },
    { name: "Electronics & Communication", code: "ECE" },
    { name: "Mechanical Engineering", code: "ME" },
    { name: "Civil Engineering", code: "CE" },
  ];
  for (const dept of depts) {
    const exists = await db.select().from(departmentsTable).where(eq(departmentsTable.code, dept.code));
    if (exists.length === 0) {
      await db.insert(departmentsTable).values(dept);
      console.log(`Created department: ${dept.code}`);
    }
  }

  // Subjects
  const [cseDept] = await db.select().from(departmentsTable).where(eq(departmentsTable.code, "CSE"));
  const subjects = [
    { name: "Data Structures", code: "CS301", departmentId: cseDept?.id },
    { name: "Algorithms", code: "CS302", departmentId: cseDept?.id },
    { name: "Database Systems", code: "CS303", departmentId: cseDept?.id },
    { name: "Operating Systems", code: "CS304", departmentId: cseDept?.id },
    { name: "Computer Networks", code: "CS305", departmentId: cseDept?.id },
  ];
  for (const subj of subjects) {
    const exists = await db.select().from(subjectsTable).where(eq(subjectsTable.code, subj.code));
    if (exists.length === 0) {
      await db.insert(subjectsTable).values(subj);
      console.log(`Created subject: ${subj.code}`);
    }
  }

  // Classes
  const classes = [
    { branch: "CSE", semester: "5", section: "A" },
    { branch: "CSE", semester: "5", section: "B" },
    { branch: "ECE", semester: "3", section: "A" },
  ];
  for (const cls of classes) {
    const exists = await db.select().from(classesTable).where(eq(classesTable.branch, cls.branch));
    if (exists.length === 0) {
      await db.insert(classesTable).values(cls);
      console.log(`Created class: ${cls.branch} Sem${cls.semester} ${cls.section}`);
    }
  }

  // Faculty
  const facultyData = [
    { name: "Dr. Priya Sharma", email: "faculty@portal.edu", password: "faculty123", department: "CSE", designation: "Professor" },
    { name: "Prof. Rajesh Kumar", email: "rajesh@portal.edu", password: "faculty123", department: "ECE", designation: "Associate Professor" },
  ];
  for (const f of facultyData) {
    const exists = await db.select().from(usersTable).where(eq(usersTable.email, f.email));
    if (exists.length === 0) {
      const hashed = await bcrypt.hash(f.password, 10);
      const [user] = await db.insert(usersTable).values({ name: f.name, email: f.email, password: hashed, role: "faculty" }).returning();
      await db.insert(facultyTable).values({ userId: user.id, department: f.department, designation: f.designation });
      console.log(`Created faculty: ${f.email} / ${f.password}`);
    }
  }

  // Students
  const studentsData = [
    { name: "Alice Johnson", email: "student@portal.edu", password: "student123", branch: "CSE", semester: "5", section: "A", rollNumber: "CSE501A001" },
    { name: "Bob Smith", email: "bob@portal.edu", password: "student123", branch: "CSE", semester: "5", section: "A", rollNumber: "CSE501A002" },
    { name: "Carol White", email: "carol@portal.edu", password: "student123", branch: "CSE", semester: "5", section: "B", rollNumber: "CSE501B001" },
    { name: "David Lee", email: "david@portal.edu", password: "student123", branch: "ECE", semester: "3", section: "A", rollNumber: "ECE301A001" },
  ];
  for (const s of studentsData) {
    const exists = await db.select().from(usersTable).where(eq(usersTable.email, s.email));
    if (exists.length === 0) {
      const hashed = await bcrypt.hash(s.password, 10);
      const [user] = await db.insert(usersTable).values({ name: s.name, email: s.email, password: hashed, role: "student" }).returning();
      await db.insert(studentsTable).values({ userId: user.id, branch: s.branch, semester: s.semester, section: s.section, rollNumber: s.rollNumber });
      console.log(`Created student: ${s.email} / ${s.password}`);
    }
  }

  // Notices
  const noticeExists = await db.select().from(noticesTable).limit(1);
  if (noticeExists.length === 0) {
    await db.insert(noticesTable).values([
      { title: "Mid-Semester Examination Schedule", description: "Mid-semester examinations will be held from October 15-20. Students must carry their hall tickets." },
      { title: "Library Hours Extended", description: "The central library will remain open until 10 PM during examination season." },
      { title: "Sports Day Registration", description: "Annual sports day registration is now open. Register at the sports office before October 10." },
    ]);
    console.log("Created sample notices");
  }

  // Announcements
  const annExists = await db.select().from(announcementsTable).limit(1);
  if (annExists.length === 0) {
    await db.insert(announcementsTable).values([
      { title: "Welcome to the New Academic Year", description: "The department welcomes all students to the new academic year 2024-25. Classes begin Monday.", priority: "high" },
      { title: "Campus Wi-Fi Maintenance", description: "Campus network will be down on Saturday from 2 AM to 6 AM for maintenance.", priority: "medium" },
      { title: "New Lab Equipment Available", description: "The computer lab has been upgraded with new workstations. Lab sessions can resume normally.", priority: "low" },
    ]);
    console.log("Created sample announcements");
  }

  // Activity
  const actExists = await db.select().from(activityTable).limit(1);
  if (actExists.length === 0) {
    await db.insert(activityTable).values([
      { type: "user_created", message: "New student Alice Johnson enrolled", actor: "Admin" },
      { type: "notice_posted", message: "Notice posted: Mid-Semester Examination Schedule", actor: "Admin" },
      { type: "announcement_created", message: "Announcement posted: Welcome to the New Academic Year", actor: "Admin" },
    ]);
    console.log("Created activity log");
  }

  console.log("\nSeed complete!");
  console.log("Login credentials:");
  console.log("  Admin:   admin@portal.edu   / admin123");
  console.log("  Faculty: faculty@portal.edu / faculty123");
  console.log("  Student: student@portal.edu / student123");
  process.exit(0);
}

seed().catch(e => { console.error(e); process.exit(1); });
