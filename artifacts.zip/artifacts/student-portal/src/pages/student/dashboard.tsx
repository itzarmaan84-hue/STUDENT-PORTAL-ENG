import { useGetStudentSummary, useGetRecentActivity, useListNotices, useListAnnouncements, getGetStudentSummaryQueryKey, getGetRecentActivityQueryKey, getListNoticesQueryKey, getListAnnouncementsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { CalendarCheck2, FileText, Bell, Megaphone, BookOpen, TrendingUp } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

function StatCard({ title, value, icon: Icon, sub }: { title: string; value: string | number; icon: React.ElementType; sub?: string }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold mt-1" data-testid={`stat-${title.toLowerCase().replace(/\s/g, "-")}`}>{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
          </div>
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Icon className="w-5 h-5 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function StudentDashboard() {
  const { user } = useAuth();
  const { data: summary, isLoading } = useGetStudentSummary({ query: { queryKey: getGetStudentSummaryQueryKey() } });
  const { data: activity } = useGetRecentActivity({ query: { queryKey: getGetRecentActivityQueryKey() } });
  const { data: notices } = useListNotices({ query: { queryKey: getListNoticesQueryKey() } });
  const { data: announcements } = useListAnnouncements({ query: { queryKey: getListAnnouncementsQueryKey() } });

  return (
    <div className="p-8" data-testid="page-student-dashboard">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Welcome back, {user?.name?.split(" ")[0]}</h1>
        <p className="text-muted-foreground text-sm">Here's your academic overview</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          <StatCard title="Attendance" value={`${summary?.attendancePercentage ?? 0}%`} icon={CalendarCheck2}
            sub={summary?.attendancePercentage && summary.attendancePercentage < 75 ? "Below required 75%" : "Good standing"} />
          <StatCard title="Upcoming Assignments" value={summary?.upcomingAssignments ?? 0} icon={FileText} sub="Due soon" />
          <StatCard title="Total Subjects" value={summary?.totalSubjects ?? 0} icon={BookOpen} />
          <StatCard title="Average Marks" value={`${summary?.averageMarks ?? 0}`} icon={TrendingUp} sub="Internal assessment" />
          <StatCard title="Notices" value={summary?.unreadNotices ?? 0} icon={Bell} />
          <StatCard title="Announcements" value={summary?.unreadAnnouncements ?? 0} icon={Megaphone} />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><Bell className="w-4 h-4" />Recent Notices</CardTitle>
          </CardHeader>
          <CardContent>
            {notices && notices.length > 0 ? (
              <div className="space-y-3">
                {notices.slice(0, 5).map(n => (
                  <div key={n.id} className="border-l-2 border-primary/30 pl-3" data-testid={`notice-item-${n.id}`}>
                    <p className="text-sm font-medium">{n.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.description}</p>
                    <p className="text-xs text-muted-foreground mt-1">{new Date(n.createdAt).toLocaleDateString()}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No notices yet</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><Megaphone className="w-4 h-4" />Announcements</CardTitle>
          </CardHeader>
          <CardContent>
            {announcements && announcements.length > 0 ? (
              <div className="space-y-3">
                {announcements.slice(0, 5).map(a => (
                  <div key={a.id} className="flex items-start gap-3" data-testid={`announcement-item-${a.id}`}>
                    <Badge variant={a.priority === "high" ? "destructive" : a.priority === "medium" ? "default" : "secondary"} className="text-xs mt-0.5 shrink-0">
                      {a.priority}
                    </Badge>
                    <div>
                      <p className="text-sm font-medium">{a.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{a.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No announcements yet</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
