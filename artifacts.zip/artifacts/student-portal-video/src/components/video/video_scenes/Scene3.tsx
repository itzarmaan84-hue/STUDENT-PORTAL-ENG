import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video/animations';

export function Scene3() {
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 200),
      setTimeout(() => setPhase(2), 600),
      setTimeout(() => setPhase(3), 1400),
      setTimeout(() => setPhase(4), 3000),
    ];
    return () => timers.forEach(t => clearTimeout(t));
  }, []);

  return (
    <motion.div className="absolute inset-0 flex items-center justify-end px-[10vw]"
      {...sceneTransitions.splitHorizontal}>
      
      <div className="absolute left-0 top-0 bottom-0 w-[60%] z-0">
        <img src={`${import.meta.env.BASE_URL}images/faculty.jpg`} className="w-full h-full object-cover opacity-50" alt="" />
        <div className="absolute inset-0 bg-gradient-to-l from-bg-dark to-transparent" />
      </div>

      <div className="relative z-10 w-[45%] text-right">
        <motion.div 
          className="text-accent-2 text-[1.5vw] font-mono mb-4 flex justify-end"
          initial={{ opacity: 0, x: 20 }}
          animate={phase >= 1 ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
        >
          // ROLE: FACULTY
        </motion.div>

        <motion.h2 
          className="text-[5.5vw] font-display font-bold leading-tight mb-8"
          initial={{ opacity: 0, y: 40 }}
          animate={phase >= 2 ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
        >
          TEACH.<br />TRACK. <span className="text-accent-2">EVALUATE.</span>
        </motion.h2>

        <div className="flex justify-end gap-6">
          {['ATTENDANCE', 'ASSIGNMENTS', 'MARKS'].map((stat, i) => (
            <motion.div 
              key={i}
              className="bg-secondary/80 backdrop-blur border border-white/10 px-6 py-4 rounded-xl text-center"
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={phase >= 3 ? { opacity: 1, scale: 1, y: 0 } : { opacity: 0, scale: 0.8, y: 20 }}
              transition={{ delay: i * 0.15, type: "spring" }}
            >
              <div className="text-[1vw] text-text-muted font-mono mb-2">{stat}</div>
              <div className="w-8 h-1 bg-accent-2 mx-auto" />
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
