import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import dashboardRouter from "./dashboard";
import studentsRouter from "./students";
import facultyRouter from "./faculty";
import departmentsRouter from "./departments";
import subjectsRouter from "./subjects";
import classesRouter from "./classes";
import attendanceRouter from "./attendance";
import assignmentsRouter from "./assignments";
import noticesRouter from "./notices";
import announcementsRouter from "./announcements";
import marksRouter from "./marks";
import timetableRouter from "./timetable";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(dashboardRouter);
router.use(studentsRouter);
router.use(facultyRouter);
router.use(departmentsRouter);
router.use(subjectsRouter);
router.use(classesRouter);
router.use(attendanceRouter);
router.use(assignmentsRouter);
router.use(noticesRouter);
router.use(announcementsRouter);
router.use(marksRouter);
router.use(timetableRouter);

export default router;
