import { useState } from "react";
import { useListTimetable, useCreateTimetableEntry, useDeleteTimetableEntry, useListClasses, useListSubjects, useListFaculty, getListTimetableQueryKey, getListClassesQueryKey, getListSubjectsQueryKey, getListFacultyQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2 } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

const DAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"] as const;
const schema = z.object({ classId: z.string().min(1), subjectId: z.string().min(1), facultyId: z.string().optional(), day: z.enum(DAYS), startTime: z.string().min(1), endTime: z.string().min(1) });

export default function AdminTimetable() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const { data: entries, isLoading } = useListTimetable({}, { query: { queryKey: getListTimetableQueryKey({}) } });
  const { data: classes } = useListClasses({ query: { queryKey: getListClassesQueryKey() } });
  const { data: subjects } = useListSubjects({}, { query: { queryKey: getListSubjectsQueryKey({}) } });
  const { data: faculty } = useListFaculty({}, { query: { queryKey: getListFacultyQueryKey({}) } });
  const createMutation = useCreateTimetableEntry();
  const deleteMutation = useDeleteTimetableEntry();

  const form = useForm({ resolver: zodResolver(schema), defaultValues: { classId: "", subjectId: "", facultyId: "", day: "Monday" as const, startTime: "09:00", endTime: "10:00" } });

  const onSubmit = (data: z.infer<typeof schema>) => {
    createMutation.mutate({ data: { classId: parseInt(data.classId), subjectId: parseInt(data.subjectId), facultyId: data.facultyId ? parseInt(data.facultyId) : undefined, day: data.day, startTime: data.startTime, endTime: data.endTime } }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListTimetableQueryKey({}) }); toast({ title: "Entry added" }); setOpen(false); form.reset(); },
      onError: (e) => toast({ title: "Failed", description: e instanceof Error ? e.message : undefined, variant: "destructive" }),
    });
  };

  const handleDelete = () => {
    if (!deleteId) return;
    deleteMutation.mutate({ id: deleteId }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListTimetableQueryKey({}) }); toast({ title: "Deleted" }); setDeleteId(null); },
      onError: () => toast({ title: "Delete failed", variant: "destructive" }),
    });
  };

  return (
    <div className="p-8" data-testid="page-admin-timetable">
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="text-2xl font-bold">Timetable</h1><p className="text-muted-foreground text-sm">Manage class schedules</p></div>
        <Button onClick={() => setOpen(true)} data-testid="button-add-entry"><Plus className="w-4 h-4 mr-1" />Add Entry</Button>
      </div>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader><TableRow><TableHead>Day</TableHead><TableHead>Time</TableHead><TableHead>Subject</TableHead><TableHead>Faculty</TableHead><TableHead>Class</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">Loading...</TableCell></TableRow>
              ) : entries && entries.length > 0 ? entries.map(e => (
                <TableRow key={e.id} data-testid={`timetable-row-${e.id}`}>
                  <TableCell className="font-medium">{e.day}</TableCell>
                  <TableCell className="font-mono text-sm">{e.startTime} – {e.endTime}</TableCell>
                  <TableCell>{e.subjectName ?? "—"}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{e.facultyName ?? "—"}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{e.className ?? "—"}</TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="ghost" onClick={() => setDeleteId(e.id)} data-testid={`button-delete-${e.id}`}><Trash2 className="w-3.5 h-3.5" /></Button>
                  </TableCell>
                </TableRow>
              )) : (
                <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No timetable entries</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add Timetable Entry</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="classId" render={({ field }) => (
                  <FormItem><FormLabel>Class</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger data-testid="select-class"><SelectValue placeholder="Select class" /></SelectTrigger></FormControl>
                      <SelectContent>{classes?.map(c => <SelectItem key={c.id} value={String(c.id)}>{c.branch} Sem{c.semester} {c.section}</SelectItem>)}</SelectContent>
                    </Select><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="subjectId" render={({ field }) => (
                  <FormItem><FormLabel>Subject</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select subject" /></SelectTrigger></FormControl>
                      <SelectContent>{subjects?.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}</SelectContent>
                    </Select><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="facultyId" render={({ field }) => (
                  <FormItem><FormLabel>Faculty (optional)</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select faculty" /></SelectTrigger></FormControl>
                      <SelectContent><SelectItem value="none">None</SelectItem>{faculty?.map(f => <SelectItem key={f.id} value={String(f.id)}>{f.name}</SelectItem>)}</SelectContent>
                    </Select><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="day" render={({ field }) => (
                  <FormItem><FormLabel>Day</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>{DAYS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                    </Select><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="startTime" render={({ field }) => (<FormItem><FormLabel>Start Time</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage /></FormItem>)} />
                <FormField control={form.control} name="endTime" render={({ field }) => (<FormItem><FormLabel>End Time</FormLabel><FormControl><Input type="time" {...field} /></FormControl><FormMessage /></FormItem>)} />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button type="submit" data-testid="button-confirm-add" disabled={createMutation.isPending}>{createMutation.isPending ? "Adding..." : "Add Entry"}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={v => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete entry?</AlertDialogTitle><AlertDialogDescription>Remove this timetable slot?</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
