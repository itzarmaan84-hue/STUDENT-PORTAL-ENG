import { useListTimetable, getListTimetableQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

const DAYS = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"] as const;

export default function StudentTimetable() {
  const { data: entries, isLoading } = useListTimetable({}, { query: { queryKey: getListTimetableQueryKey({}) } });

  type TimetableEntry = NonNullable<typeof entries>[number];
  const byDay = DAYS.reduce((acc, d) => {
    acc[d] = (entries ?? []).filter(e => e.day === d).sort((a, b) => a.startTime.localeCompare(b.startTime));
    return acc;
  }, {} as Record<string, TimetableEntry[]>);

  return (
    <div className="p-8" data-testid="page-timetable">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Timetable</h1>
        <p className="text-muted-foreground text-sm">Your weekly class schedule</p>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)}
        </div>
      ) : (
        <div className="space-y-4">
          {DAYS.map(day => (
            <Card key={day}>
              <CardHeader className="pb-2 pt-4">
                <CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">{day}</CardTitle>
              </CardHeader>
              <CardContent className="pb-4">
                {byDay[day] && byDay[day].length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {byDay[day].map(entry => (
                      <div key={entry.id} className="bg-muted/40 rounded-lg p-3" data-testid={`timetable-entry-${entry.id}`}>
                        <div className="font-medium text-sm">{entry.subjectName ?? "—"}</div>
                        <div className="text-xs text-muted-foreground mt-1">{entry.startTime} – {entry.endTime}</div>
                        {entry.facultyName && <div className="text-xs text-muted-foreground mt-0.5">{entry.facultyName}</div>}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No classes</p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
