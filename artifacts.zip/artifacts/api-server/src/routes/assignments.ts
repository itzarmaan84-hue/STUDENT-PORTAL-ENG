import { Router } from "express";
import { db } from "@workspace/db";
import { assignmentsTable, submissionsTable, subjectsTable, facultyTable, usersTable, studentsTable } from "@workspace/db";
import { eq, and, SQL } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";
import {
  ListAssignmentsQueryParams, CreateAssignmentBody,
  GetAssignmentParams, UpdateAssignmentParams, UpdateAssignmentBody, DeleteAssignmentParams,
  SubmitAssignmentParams, SubmitAssignmentBody, ListSubmissionsParams,
} from "@workspace/api-zod";

const router = Router();

const enrichAssignment = async (a: typeof assignmentsTable.$inferSelect, userId: number) => {
  const [subj] = await db.select().from(subjectsTable).where(eq(subjectsTable.id, a.subjectId));
  let facultyName = null;
  if (a.facultyId) {
    const [fac] = await db.select({ name: usersTable.name }).from(facultyTable).innerJoin(usersTable, eq(facultyTable.userId, usersTable.id)).where(eq(facultyTable.id, a.facultyId));
    facultyName = fac?.name ?? null;
  }
  const [submissionCount] = await db.select({ cnt: submissionsTable.id }).from(submissionsTable).where(eq(submissionsTable.assignmentId, a.id)).limit(100);
  const allSubs = await db.select().from(submissionsTable).where(eq(submissionsTable.assignmentId, a.id));

  const [student] = await db.select().from(studentsTable).where(eq(studentsTable.userId, userId));
  const mySubmission = student ? allSubs.find(s => s.studentId === student.id) : null;

  return {
    ...a,
    subjectName: subj?.name ?? null,
    facultyName,
    submissionCount: allSubs.length,
    mySubmission: mySubmission ? {
      id: mySubmission.id, assignmentId: mySubmission.assignmentId, studentId: mySubmission.studentId,
      studentName: null, fileUrl: mySubmission.fileUrl, notes: mySubmission.notes,
      submissionDate: mySubmission.submissionDate.toISOString(),
    } : null,
    createdAt: a.createdAt.toISOString(),
  };
};

router.get("/assignments", requireAuth, async (req, res): Promise<void> => {
  const params = ListAssignmentsQueryParams.safeParse(req.query);
  const filters: SQL[] = [];
  if (params.success) {
    if (params.data.subjectId) filters.push(eq(assignmentsTable.subjectId, params.data.subjectId));
    if (params.data.classId) filters.push(eq(assignmentsTable.classId, params.data.classId));
  }
  const rows = await db.select().from(assignmentsTable).where(filters.length > 0 ? and(...filters) : undefined).orderBy(assignmentsTable.dueDate);
  const enriched = await Promise.all(rows.map(a => enrichAssignment(a, req.user!.userId)));
  res.json(enriched);
});

router.post("/assignments", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateAssignmentBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [asgn] = await db.insert(assignmentsTable).values({
    ...parsed.data,
    classId: parsed.data.classId ?? null,
    facultyId: parsed.data.facultyId ?? null,
    attachment: parsed.data.attachment ?? null,
  }).returning();
  res.status(201).json(await enrichAssignment(asgn, req.user!.userId));
});

router.get("/assignments/:id", requireAuth, async (req, res): Promise<void> => {
  const params = GetAssignmentParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [asgn] = await db.select().from(assignmentsTable).where(eq(assignmentsTable.id, params.data.id));
  if (!asgn) { res.status(404).json({ error: "Assignment not found" }); return; }
  res.json(await enrichAssignment(asgn, req.user!.userId));
});

router.patch("/assignments/:id", requireAuth, async (req, res): Promise<void> => {
  const params = UpdateAssignmentParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateAssignmentBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [asgn] = await db.update(assignmentsTable).set(parsed.data).where(eq(assignmentsTable.id, params.data.id)).returning();
  if (!asgn) { res.status(404).json({ error: "Assignment not found" }); return; }
  res.json(await enrichAssignment(asgn, req.user!.userId));
});

router.delete("/assignments/:id", requireAuth, async (req, res): Promise<void> => {
  const params = DeleteAssignmentParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [asgn] = await db.delete(assignmentsTable).where(eq(assignmentsTable.id, params.data.id)).returning();
  if (!asgn) { res.status(404).json({ error: "Assignment not found" }); return; }
  res.sendStatus(204);
});

router.post("/assignments/:id/submit", requireAuth, async (req, res): Promise<void> => {
  const params = SubmitAssignmentParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = SubmitAssignmentBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [student] = await db.select().from(studentsTable).where(eq(studentsTable.userId, req.user!.userId));
  if (!student) { res.status(400).json({ error: "Must be a student" }); return; }
  const [sub] = await db.insert(submissionsTable).values({
    assignmentId: params.data.id,
    studentId: student.id,
    fileUrl: parsed.data.fileUrl ?? null,
    notes: parsed.data.notes ?? null,
  }).returning();
  res.status(201).json({ ...sub, studentName: null, submissionDate: sub.submissionDate.toISOString() });
});

router.get("/assignments/:id/submissions", requireAuth, async (req, res): Promise<void> => {
  const params = ListSubmissionsParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const rows = await db.select({
    id: submissionsTable.id, assignmentId: submissionsTable.assignmentId,
    studentId: submissionsTable.studentId, fileUrl: submissionsTable.fileUrl,
    notes: submissionsTable.notes, submissionDate: submissionsTable.submissionDate,
    studentName: usersTable.name,
  }).from(submissionsTable)
    .leftJoin(studentsTable, eq(submissionsTable.studentId, studentsTable.id))
    .leftJoin(usersTable, eq(studentsTable.userId, usersTable.id))
    .where(eq(submissionsTable.assignmentId, params.data.id));
  res.json(rows.map(r => ({ ...r, submissionDate: r.submissionDate.toISOString() })));
});

export default router;
