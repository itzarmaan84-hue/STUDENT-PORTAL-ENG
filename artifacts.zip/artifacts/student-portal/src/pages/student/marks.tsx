import { useListMarks, getListMarksQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

export default function StudentMarks() {
  const { data: marks, isLoading } = useListMarks({}, { query: { queryKey: getListMarksQueryKey({}) } });

  const avg = marks && marks.length > 0 ? Math.round(marks.reduce((s, m) => s + (m.total ?? 0), 0) / marks.length) : 0;

  return (
    <div className="p-8" data-testid="page-marks">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Marks</h1>
        <p className="text-muted-foreground text-sm">Your internal assessment marks</p>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <Card><CardContent className="pt-5"><p className="text-sm text-muted-foreground">Subjects</p><p className="text-2xl font-bold mt-1">{marks?.length ?? 0}</p></CardContent></Card>
        <Card><CardContent className="pt-5"><p className="text-sm text-muted-foreground">Average Total</p><p className="text-2xl font-bold mt-1" data-testid="stat-avg-marks">{avg}</p></CardContent></Card>
        <Card><CardContent className="pt-5"><p className="text-sm text-muted-foreground">Highest</p><p className="text-2xl font-bold mt-1">{marks ? Math.max(...marks.map(m => m.total ?? 0)) : 0}</p></CardContent></Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Marks Sheet</CardTitle></CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
          ) : marks && marks.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Subject</TableHead>
                  <TableHead className="text-right">Internal 1 <span className="text-muted-foreground font-normal">/30</span></TableHead>
                  <TableHead className="text-right">Internal 2 <span className="text-muted-foreground font-normal">/30</span></TableHead>
                  <TableHead className="text-right">Assignment <span className="text-muted-foreground font-normal">/20</span></TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead className="text-right">Grade</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {marks.map(m => (
                  <TableRow key={m.id} data-testid={`marks-row-${m.id}`}>
                    <TableCell className="font-medium">{m.subjectName ?? "—"}</TableCell>
                    <TableCell className="text-right">{m.internal1 ?? "—"}</TableCell>
                    <TableCell className="text-right">{m.internal2 ?? "—"}</TableCell>
                    <TableCell className="text-right">{m.assignmentMarks ?? "—"}</TableCell>
                    <TableCell className="text-right font-semibold">{m.total ?? "—"}</TableCell>
                    <TableCell className="text-right">
                      {m.total != null && (
                        <Badge variant={m.total >= 60 ? "default" : m.total >= 45 ? "secondary" : "destructive"}>
                          {m.total >= 75 ? "A" : m.total >= 60 ? "B" : m.total >= 45 ? "C" : "F"}
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-sm text-muted-foreground py-4 text-center">No marks recorded yet</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
