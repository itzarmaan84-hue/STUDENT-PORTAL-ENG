import { useState } from "react";
import { useListStudents, useListSubjects, useMarkAttendance, getListStudentsQueryKey, getListSubjectsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";

type AttendanceStatus = "present" | "absent" | "late";

export default function FacultyAttendance() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [subjectId, setSubjectId] = useState<string>("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [attendance, setAttendance] = useState<Record<number, AttendanceStatus>>({});
  const [submitted, setSubmitted] = useState(false);

  const { data: subjects } = useListSubjects({}, { query: { queryKey: getListSubjectsQueryKey({}) } });
  const { data: students } = useListStudents({}, { query: { queryKey: getListStudentsQueryKey({}) } });
  const markMutation = useMarkAttendance();

  const handleMark = (studentId: number, status: AttendanceStatus) => {
    setAttendance(prev => ({ ...prev, [studentId]: status }));
  };

  const handleMarkAll = (status: AttendanceStatus) => {
    if (!students) return;
    const all = Object.fromEntries(students.map(s => [s.id, status]));
    setAttendance(all as Record<number, AttendanceStatus>);
  };

  const handleSubmit = () => {
    if (!subjectId || !students) return;
    const records = students.map(s => ({ studentId: s.id, status: attendance[s.id] ?? "absent" }));
    markMutation.mutate({ data: { subjectId: parseInt(subjectId), date, records } }, {
      onSuccess: () => {
        toast({ title: "Attendance marked successfully" });
        setSubmitted(true);
      },
      onError: () => toast({ title: "Failed to mark attendance", variant: "destructive" }),
    });
  };

  return (
    <div className="p-8" data-testid="page-faculty-attendance">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Mark Attendance</h1>
        <p className="text-muted-foreground text-sm">Record attendance for a class session</p>
      </div>

      <Card className="mb-6">
        <CardContent className="pt-5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium block mb-1.5">Subject</label>
              <Select value={subjectId} onValueChange={setSubjectId}>
                <SelectTrigger data-testid="select-subject"><SelectValue placeholder="Select subject" /></SelectTrigger>
                <SelectContent>
                  {subjects?.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium block mb-1.5">Date</label>
              <Input type="date" value={date} onChange={e => setDate(e.target.value)} data-testid="input-date" />
            </div>
            <div className="flex items-end gap-2">
              <Button variant="outline" size="sm" onClick={() => handleMarkAll("present")} data-testid="button-all-present">All Present</Button>
              <Button variant="outline" size="sm" onClick={() => handleMarkAll("absent")}>All Absent</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {students && students.length > 0 ? (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Students ({students.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Roll No.</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Branch / Section</TableHead>
                  <TableHead className="text-center">Present</TableHead>
                  <TableHead className="text-center">Absent</TableHead>
                  <TableHead className="text-center">Late</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students.map(s => (
                  <TableRow key={s.id} data-testid={`student-row-${s.id}`}>
                    <TableCell className="font-mono text-sm">{s.rollNumber}</TableCell>
                    <TableCell className="font-medium">{s.name}</TableCell>
                    <TableCell className="text-muted-foreground text-sm">{s.branch} / {s.section}</TableCell>
                    {(["present","absent","late"] as AttendanceStatus[]).map(status => (
                      <TableCell key={status} className="text-center">
                        <button
                          data-testid={`btn-${status}-${s.id}`}
                          onClick={() => handleMark(s.id, status)}
                          className={`w-6 h-6 rounded-full border-2 transition-all ${
                            attendance[s.id] === status
                              ? status === "present" ? "bg-green-500 border-green-500" : status === "absent" ? "bg-red-500 border-red-500" : "bg-yellow-500 border-yellow-500"
                              : "border-muted-foreground/30 hover:border-muted-foreground"
                          }`}
                        />
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="mt-4 flex justify-end">
              <Button onClick={handleSubmit} disabled={!subjectId || markMutation.isPending || submitted} data-testid="button-submit-attendance">
                {markMutation.isPending ? "Submitting..." : submitted ? "Submitted" : "Submit Attendance"}
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <p className="text-sm text-muted-foreground">No students found</p>
      )}
    </div>
  );
}
