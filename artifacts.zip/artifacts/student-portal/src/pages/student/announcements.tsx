import { useListAnnouncements, getListAnnouncementsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Megaphone } from "lucide-react";

export default function StudentAnnouncements() {
  const { data: announcements, isLoading } = useListAnnouncements({ query: { queryKey: getListAnnouncementsQueryKey() } });

  return (
    <div className="p-8" data-testid="page-announcements">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Announcements</h1>
        <p className="text-muted-foreground text-sm">Updates from faculty and administration</p>
      </div>

      {isLoading ? (
        <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-xl" />)}</div>
      ) : announcements && announcements.length > 0 ? (
        <div className="space-y-3">
          {[...announcements].reverse().map(a => (
            <Card key={a.id} data-testid={`announcement-card-${a.id}`}>
              <CardContent className="pt-5 pb-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex gap-3">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                      <Megaphone className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-sm">{a.title}</h3>
                        <Badge variant={a.priority === "high" ? "destructive" : a.priority === "medium" ? "default" : "secondary"} className="text-xs">
                          {a.priority}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{a.description}</p>
                      <div className="text-xs text-muted-foreground mt-2 flex gap-3">
                        {a.authorName && <span>By {a.authorName}</span>}
                        <span>{new Date(a.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 text-muted-foreground">
          <Megaphone className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>No announcements yet</p>
        </div>
      )}
    </div>
  );
}
