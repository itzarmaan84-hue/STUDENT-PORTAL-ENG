import { Router } from "express";
import { db } from "@workspace/db";
import { noticesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";
import { CreateNoticeBody, UpdateNoticeParams, UpdateNoticeBody, DeleteNoticeParams } from "@workspace/api-zod";

const router = Router();

router.get("/notices", requireAuth, async (_req, res): Promise<void> => {
  const rows = await db.select().from(noticesTable).orderBy(noticesTable.createdAt);
  res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/notices", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const parsed = CreateNoticeBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [notice] = await db.insert(noticesTable).values({ ...parsed.data, attachment: parsed.data.attachment ?? null }).returning();
  res.status(201).json({ ...notice, createdAt: notice.createdAt.toISOString() });
});

router.patch("/notices/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = UpdateNoticeParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateNoticeBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [notice] = await db.update(noticesTable).set(parsed.data).where(eq(noticesTable.id, params.data.id)).returning();
  if (!notice) { res.status(404).json({ error: "Notice not found" }); return; }
  res.json({ ...notice, createdAt: notice.createdAt.toISOString() });
});

router.delete("/notices/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = DeleteNoticeParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [notice] = await db.delete(noticesTable).where(eq(noticesTable.id, params.data.id)).returning();
  if (!notice) { res.status(404).json({ error: "Notice not found" }); return; }
  res.sendStatus(204);
});

export default router;
