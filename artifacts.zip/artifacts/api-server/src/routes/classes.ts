import { Router } from "express";
import { db } from "@workspace/db";
import { classesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";
import { CreateClassBody, UpdateClassParams, UpdateClassBody, DeleteClassParams } from "@workspace/api-zod";

const router = Router();

router.get("/classes", requireAuth, async (_req, res): Promise<void> => {
  const rows = await db.select().from(classesTable).orderBy(classesTable.branch, classesTable.semester);
  res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/classes", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const parsed = CreateClassBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [cls] = await db.insert(classesTable).values(parsed.data).returning();
  res.status(201).json({ ...cls, createdAt: cls.createdAt.toISOString() });
});

router.patch("/classes/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = UpdateClassParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateClassBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [cls] = await db.update(classesTable).set(parsed.data).where(eq(classesTable.id, params.data.id)).returning();
  if (!cls) { res.status(404).json({ error: "Class not found" }); return; }
  res.json({ ...cls, createdAt: cls.createdAt.toISOString() });
});

router.delete("/classes/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = DeleteClassParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [cls] = await db.delete(classesTable).where(eq(classesTable.id, params.data.id)).returning();
  if (!cls) { res.status(404).json({ error: "Class not found" }); return; }
  res.sendStatus(204);
});

export default router;
