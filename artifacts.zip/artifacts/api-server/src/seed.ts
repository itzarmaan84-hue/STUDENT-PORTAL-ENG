import { db } from "@workspace/db";
import {
  usersTable, studentsTable, facultyTable, departmentsTable,
  subjectsTable, classesTable, announcementsTable, noticesTable,
  activityTable, timetableTable, assignmentsTable, attendanceTable,
  marksTable,
} from "@workspace/db";
import bcrypt from "bcryptjs";
import { eq, and, sql } from "drizzle-orm";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function dateOffset(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().split("T")[0];
}

async function upsertUser(
  data: { name: string; email: string; password: string; role: "admin" | "faculty" | "student"; phone?: string },
) {
  const hashed = await bcrypt.hash(data.password, 10);
  const [user] = await db
    .insert(usersTable)
    .values({ name: data.name, email: data.email.toLowerCase(), password: hashed, role: data.role, phone: data.phone ?? null })
    .onConflictDoUpdate({
      target: usersTable.email,
      set: { name: data.name, role: data.role },
    })
    .returning();
  return user!;
}

// ---------------------------------------------------------------------------
// Main seed
// ---------------------------------------------------------------------------

async function seed() {
  console.log("🌱  Seeding database...\n");

  await db.transaction(async (tx) => {

    // ── 1. Admin ────────────────────────────────────────────────────────────
    const adminHash = await bcrypt.hash("admin123", 10);
    await tx
      .insert(usersTable)
      .values({ name: "Admin User", email: "admin@portal.edu", password: adminHash, role: "admin", phone: "9000000000" })
      .onConflictDoNothing();
    console.log("✔  Admin user");

    // ── 2. Departments ───────────────────────────────────────────────────────
    await tx.insert(departmentsTable).values([
      { name: "Computer Science & Engineering", code: "CSE" },
      { name: "Electronics & Communication",   code: "ECE" },
      { name: "Mechanical Engineering",         code: "ME"  },
      { name: "Civil Engineering",              code: "CE"  },
    ]).onConflictDoNothing();
    console.log("✔  Departments");

    // ── 3. Subjects ──────────────────────────────────────────────────────────
    const [cseDept] = await tx.select().from(departmentsTable).where(eq(departmentsTable.code, "CSE"));
    if (!cseDept) throw new Error("CSE department not found after insert");

    await tx.insert(subjectsTable).values([
      { name: "Data Structures",    code: "CS301", departmentId: cseDept.id },
      { name: "Algorithms",         code: "CS302", departmentId: cseDept.id },
      { name: "Database Systems",   code: "CS303", departmentId: cseDept.id },
      { name: "Operating Systems",  code: "CS304", departmentId: cseDept.id },
      { name: "Computer Networks",  code: "CS305", departmentId: cseDept.id },
    ]).onConflictDoNothing();
    console.log("✔  Subjects");

    // ── 4. Classes ───────────────────────────────────────────────────────────
    await tx.insert(classesTable).values([
      { branch: "CSE", semester: "5", section: "A" },
      { branch: "CSE", semester: "5", section: "B" },
      { branch: "ECE", semester: "3", section: "A" },
    ]).onConflictDoNothing();
    console.log("✔  Classes");

    // ── 5. Faculty ───────────────────────────────────────────────────────────
    const facultyAccounts = [
      { name: "Dr. Priya Sharma",    email: "faculty@portal.edu", password: "faculty123", department: "CSE", designation: "Professor"            },
      { name: "Prof. Rajesh Kumar",  email: "rajesh@portal.edu",  password: "faculty123", department: "ECE", designation: "Associate Professor"   },
    ];
    for (const f of facultyAccounts) {
      const hash = await bcrypt.hash(f.password, 10);
      const [user] = await tx
        .insert(usersTable)
        .values({ name: f.name, email: f.email, password: hash, role: "faculty" })
        .onConflictDoNothing()
        .returning();
      if (user) {
        await tx.insert(facultyTable)
          .values({ userId: user.id, department: f.department, designation: f.designation })
          .onConflictDoNothing();
      }
    }
    console.log("✔  Faculty accounts");

    // ── 6. Students ──────────────────────────────────────────────────────────
    const studentAccounts = [
      { name: "Alice Johnson", email: "student@portal.edu", password: "student123", branch: "CSE", semester: "5", section: "A", rollNumber: "CSE501A001" },
      { name: "Bob Smith",     email: "bob@portal.edu",     password: "student123", branch: "CSE", semester: "5", section: "A", rollNumber: "CSE501A002" },
      { name: "Carol White",   email: "carol@portal.edu",   password: "student123", branch: "CSE", semester: "5", section: "B", rollNumber: "CSE501B001" },
      { name: "David Lee",     email: "david@portal.edu",   password: "student123", branch: "ECE", semester: "3", section: "A", rollNumber: "ECE301A001" },
    ];
    for (const s of studentAccounts) {
      const hash = await bcrypt.hash(s.password, 10);
      const [user] = await tx
        .insert(usersTable)
        .values({ name: s.name, email: s.email, password: hash, role: "student" })
        .onConflictDoNothing()
        .returning();
      if (user) {
        await tx.insert(studentsTable)
          .values({ userId: user.id, branch: s.branch, semester: s.semester, section: s.section, rollNumber: s.rollNumber })
          .onConflictDoNothing();
      }
    }
    console.log("✔  Student accounts");

    // ── 7. Notices ───────────────────────────────────────────────────────────
    const existingNotices = await tx.select({ cnt: sql<number>`count(*)::int` }).from(noticesTable);
    if ((existingNotices[0]?.cnt ?? 0) === 0) {
      await tx.insert(noticesTable).values([
        { title: "Mid-Semester Examination Schedule",   description: "Mid-semester examinations will be held from October 15-20. Students must carry their hall tickets. No electronic devices allowed." },
        { title: "Library Hours Extended",              description: "The central library will remain open until 10 PM during examination season. Students are encouraged to utilise all resources." },
        { title: "Sports Day Registration Open",        description: "Annual sports day registration is now open. Register at the sports office before October 10. Events: cricket, football, badminton, athletics." },
        { title: "Anti-Ragging Committee Notice",       description: "The institute has zero-tolerance towards ragging. Any incident must be reported immediately to the student welfare office." },
        { title: "Fee Payment Deadline",                description: "Last date for fee payment for the current semester is October 31. Late payments attract a fine of ₹500 per day." },
      ]);
      console.log("✔  Notices (5 created)");
    } else {
      console.log("✔  Notices (already seeded)");
    }

    // ── 8. Announcements ─────────────────────────────────────────────────────
    const existingAnn = await tx.select({ cnt: sql<number>`count(*)::int` }).from(announcementsTable);
    if ((existingAnn[0]?.cnt ?? 0) === 0) {
      await tx.insert(announcementsTable).values([
        { title: "Welcome to the New Academic Year 2024-25", description: "The department welcomes all students. Orientation sessions will be held in the main auditorium.", priority: "high"   },
        { title: "Campus Wi-Fi Maintenance",                  description: "Campus network will be down Saturday 2–6 AM for scheduled maintenance. Plan accordingly.",               priority: "medium" },
        { title: "New Lab Equipment Available",               description: "The computer lab has been upgraded with 30 new high-performance workstations. Lab sessions resume normally.", priority: "low"    },
        { title: "Guest Lecture: AI in Healthcare",           description: "Distinguished lecture by Dr. Ramesh Iyer from IIT Bombay on AI in healthcare. Attendance encouraged.",    priority: "high"   },
        { title: "Hackathon Registration",                    description: "Register for the annual 24-hour hackathon. Teams of 2-4. Prizes ₹50,000. Last date: Oct 5.",             priority: "medium" },
      ]);
      console.log("✔  Announcements (5 created)");
    } else {
      console.log("✔  Announcements (already seeded)");
    }

    // ── 9. Timetable ─────────────────────────────────────────────────────────
    const allSubjects = await tx.select().from(subjectsTable);
    const [mainFaculty] = await tx.select().from(facultyTable);
    const [cseA] = await tx
      .select()
      .from(classesTable)
      .where(and(eq(classesTable.branch, "CSE"), eq(classesTable.semester, "5"), eq(classesTable.section, "A")));

    if (cseA && allSubjects.length >= 5) {
      const s = allSubjects;
      const fId = mainFaculty?.id ?? null;
      const cId = cseA.id;
      await tx.insert(timetableTable).values([
        { classId: cId, subjectId: s[0].id, facultyId: fId, day: "Monday",    startTime: "09:00", endTime: "10:00" },
        { classId: cId, subjectId: s[1].id, facultyId: fId, day: "Monday",    startTime: "10:00", endTime: "11:00" },
        { classId: cId, subjectId: s[2].id, facultyId: fId, day: "Monday",    startTime: "11:15", endTime: "12:15" },
        { classId: cId, subjectId: s[0].id, facultyId: fId, day: "Tuesday",   startTime: "09:00", endTime: "10:00" },
        { classId: cId, subjectId: s[3].id, facultyId: fId, day: "Tuesday",   startTime: "10:00", endTime: "11:00" },
        { classId: cId, subjectId: s[4].id, facultyId: fId, day: "Tuesday",   startTime: "11:15", endTime: "12:15" },
        { classId: cId, subjectId: s[1].id, facultyId: fId, day: "Wednesday", startTime: "09:00", endTime: "10:00" },
        { classId: cId, subjectId: s[2].id, facultyId: fId, day: "Wednesday", startTime: "10:00", endTime: "11:00" },
        { classId: cId, subjectId: s[3].id, facultyId: fId, day: "Thursday",  startTime: "09:00", endTime: "10:00" },
        { classId: cId, subjectId: s[4].id, facultyId: fId, day: "Thursday",  startTime: "10:00", endTime: "11:00" },
        { classId: cId, subjectId: s[0].id, facultyId: fId, day: "Friday",    startTime: "09:00", endTime: "10:00" },
        { classId: cId, subjectId: s[1].id, facultyId: fId, day: "Friday",    startTime: "10:00", endTime: "11:00" },
      ]).onConflictDoNothing();
      console.log("✔  Timetable (12 slots)");
    }

    // ── 10. Assignments ──────────────────────────────────────────────────────
    if (mainFaculty && allSubjects.length >= 5) {
      const fId = mainFaculty.id;
      await tx.insert(assignmentsTable).values([
        { title: "Implement a Binary Search Tree",     description: "Write a complete BST in C++ with insert, delete, search, and traversal. Include time complexity analysis.",          subjectId: allSubjects[0].id, facultyId: fId, dueDate: dateOffset(7)  },
        { title: "Dynamic Programming Problems",        description: "Solve 5 DP problems: LCS, 0/1 Knapsack, Coin Change, Edit Distance, Matrix Chain Multiplication.",                  subjectId: allSubjects[1].id, facultyId: fId, dueDate: dateOffset(14) },
        { title: "ER Diagram and Normalization",        description: "Design an ER diagram for a hospital management system and normalise to 3NF. Submit PDF with explanations.",          subjectId: allSubjects[2].id, facultyId: fId, dueDate: dateOffset(3)  },
        { title: "Process Scheduling Algorithms",       description: "Implement FCFS, SJF, Round Robin, and Priority scheduling algorithms. Compare performance with test cases.",         subjectId: allSubjects[3].id, facultyId: fId, dueDate: dateOffset(-5) },
        { title: "Socket Programming Lab",              description: "Implement a TCP client-server chat application. Handle multiple clients using threads.",                             subjectId: allSubjects[4].id, facultyId: fId, dueDate: dateOffset(7)  },
      ]).onConflictDoNothing();
      console.log("✔  Assignments (5 created)");
    }

    // ── 11. Attendance ───────────────────────────────────────────────────────
    const allStudents = await tx.select().from(studentsTable);
    const alice = allStudents.find(s => s.rollNumber === "CSE501A001");
    const bob   = allStudents.find(s => s.rollNumber === "CSE501A002");
    const [fRec] = await tx.select().from(facultyTable);

    if (alice && allSubjects.length >= 5) {
      const fId = fRec?.id ?? null;
      const aliceStatuses: Array<"present" | "absent" | "late"> = [
        "present", "present", "present", "present", "absent",
        "present", "present", "late",    "present", "present",
      ];
      const bobStatuses: Array<"present" | "absent" | "late"> = [
        "present", "absent",  "present", "present", "absent",
        "absent",  "present", "present", "late",    "present",
      ];
      const records: { studentId: number; subjectId: number; facultyId: number | null; date: string; status: "present" | "absent" | "late" }[] = [];
      for (const subj of allSubjects.slice(0, 5)) {
        for (let i = 0; i < 10; i++) {
          const dateStr = dateOffset(-(10 - i));
          records.push({ studentId: alice.id, subjectId: subj.id, facultyId: fId, date: dateStr, status: aliceStatuses[i] });
          if (bob) {
            records.push({ studentId: bob.id, subjectId: subj.id, facultyId: fId, date: dateStr, status: bobStatuses[i] });
          }
        }
      }
      await tx.insert(attendanceTable).values(records).onConflictDoNothing();
      console.log(`✔  Attendance (${records.length} records, skipping duplicates)`);
    }

    // ── 12. Marks ────────────────────────────────────────────────────────────
    if (allStudents.length > 0 && allSubjects.length >= 5) {
      const markSets = [
        { internal1: 24, internal2: 22, assignmentMarks: 17 },
        { internal1: 26, internal2: 25, assignmentMarks: 18 },
        { internal1: 20, internal2: 19, assignmentMarks: 15 },
        { internal1: 28, internal2: 27, assignmentMarks: 19 },
        { internal1: 22, internal2: 23, assignmentMarks: 16 },
        { internal1: 18, internal2: 17, assignmentMarks: 14 },
        { internal1: 25, internal2: 24, assignmentMarks: 18 },
        { internal1: 21, internal2: 20, assignmentMarks: 15 },
      ];
      const marksData: { studentId: number; subjectId: number; internal1: number; internal2: number; assignmentMarks: number }[] = [];
      let idx = 0;
      for (const student of allStudents.slice(0, 3)) {
        for (const subj of allSubjects.slice(0, 5)) {
          const m = markSets[idx % markSets.length];
          marksData.push({ studentId: student.id, subjectId: subj.id, internal1: m.internal1, internal2: m.internal2, assignmentMarks: m.assignmentMarks });
          idx++;
        }
      }
      await tx.insert(marksTable).values(marksData).onConflictDoNothing();
      console.log(`✔  Marks (${marksData.length} records, skipping duplicates)`);
    }

    // ── 13. Activity log ─────────────────────────────────────────────────────
    const actCount = await tx.select({ cnt: sql<number>`count(*)::int` }).from(activityTable);
    if ((actCount[0]?.cnt ?? 0) === 0) {
      await tx.insert(activityTable).values([
        { type: "user_created",        message: "New student Alice Johnson enrolled in CSE Sem 5",         actor: "Admin"            },
        { type: "user_created",        message: "New student Bob Smith enrolled in CSE Sem 5",             actor: "Admin"            },
        { type: "user_created",        message: "New student Carol White enrolled in CSE Sem 5",           actor: "Admin"            },
        { type: "notice_posted",       message: "Notice posted: Mid-Semester Examination Schedule",        actor: "Admin"            },
        { type: "announcement_created",message: "Welcome to the New Academic Year 2024-25 announcement",  actor: "Admin"            },
        { type: "assignment_created",  message: "Assignment created: Implement a Binary Search Tree",      actor: "Dr. Priya Sharma" },
        { type: "assignment_created",  message: "Assignment created: Dynamic Programming Problems",        actor: "Dr. Priya Sharma" },
        { type: "attendance_marked",   message: "Attendance marked for CS301 — Data Structures",          actor: "Dr. Priya Sharma" },
        { type: "marks_entered",       message: "Internal marks entered for CS303 — Database Systems",    actor: "Dr. Priya Sharma" },
        { type: "marks_entered",       message: "Internal marks entered for CS301 — Data Structures",     actor: "Dr. Priya Sharma" },
      ]);
      console.log("✔  Activity log (10 entries)");
    } else {
      console.log("✔  Activity log (already seeded)");
    }

  }); // end transaction

  console.log("\n✅  Seed complete — all data committed.");
  console.log("   Admin:    admin@portal.edu   / admin123");
  console.log("   Faculty:  faculty@portal.edu / faculty123");
  console.log("   Student:  student@portal.edu / student123");
  process.exit(0);
}

seed().catch(e => {
  console.error("❌  Seed failed:", e);
  process.exit(1);
});
