import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useForgotPassword } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { useState } from "react";

const schema = z.object({ email: z.string().email("Enter a valid email") });
type FormData = z.infer<typeof schema>;

export default function ForgotPasswordPage() {
  const { toast } = useToast();
  const mutation = useForgotPassword();
  const [sent, setSent] = useState(false);

  const form = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { email: "" },
  });

  const onSubmit = (data: FormData) => {
    mutation.mutate({ data }, {
      onSuccess: () => {
        setSent(true);
        toast({ title: "Reset email sent", description: "Check your inbox for the reset link." });
      },
      onError: () => {
        setSent(true);
      },
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-8 bg-muted/30" data-testid="page-forgot-password">
      <div className="w-full max-w-sm bg-card border rounded-xl p-8 shadow-sm">
        <div className="mb-6">
          <h2 className="text-2xl font-bold">Reset password</h2>
          <p className="text-muted-foreground text-sm mt-1">Enter your email to receive a reset link</p>
        </div>

        {sent ? (
          <div className="text-center py-4">
            <p className="text-sm text-muted-foreground mb-4">If that email exists, a reset link was sent.</p>
            <Link href="/login" className="text-primary font-medium hover:underline text-sm">Back to sign in</Link>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="email" render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl><Input data-testid="input-email" type="email" placeholder="you@example.com" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <Button data-testid="button-submit" type="submit" className="w-full" disabled={mutation.isPending}>
                {mutation.isPending ? "Sending..." : "Send reset link"}
              </Button>
              <p className="text-center text-sm text-muted-foreground">
                <Link href="/login" className="text-primary hover:underline">Back to sign in</Link>
              </p>
            </form>
          </Form>
        )}
      </div>
    </div>
  );
}
