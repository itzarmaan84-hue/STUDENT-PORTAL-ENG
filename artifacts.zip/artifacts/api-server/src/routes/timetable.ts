import { Router } from "express";
import { db } from "@workspace/db";
import { timetableTable, classesTable, subjectsTable, facultyTable, studentsTable, usersTable } from "@workspace/db";
import { eq, and, SQL } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";
import { ListTimetableQueryParams, CreateTimetableEntryBody, UpdateTimetableEntryParams, UpdateTimetableEntryBody, DeleteTimetableEntryParams } from "@workspace/api-zod";

const router = Router();

const enrich = (row: {
  id: number; classId: number; subjectId: number; facultyId: number | null;
  day: string; startTime: string; endTime: string;
  className?: string | null; subjectName?: string | null; facultyName?: string | null;
}) => row;

router.get("/timetable", requireAuth, async (req, res): Promise<void> => {
  const params = ListTimetableQueryParams.safeParse(req.query);
  const filters: SQL[] = [];
  if (params.success) {
    if (params.data.classId) filters.push(eq(timetableTable.classId, params.data.classId));
    if (params.data.facultyId) filters.push(eq(timetableTable.facultyId, params.data.facultyId));
    if (params.data.day) filters.push(eq(timetableTable.day, params.data.day as "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday"));
  }
  // Students see only their class timetable
  if (req.user?.role === "student") {
    const [student] = await db.select().from(studentsTable).where(eq(studentsTable.userId, req.user.userId));
    if (student) {
      const [cls] = await db.select().from(classesTable).where(
        and(eq(classesTable.branch, student.branch), eq(classesTable.semester, student.semester), eq(classesTable.section, student.section))
      );
      if (cls) filters.push(eq(timetableTable.classId, cls.id));
    }
  }
  // Faculty see only their assigned timetable slots
  if (req.user?.role === "faculty") {
    const [faculty] = await db.select().from(facultyTable).where(eq(facultyTable.userId, req.user.userId));
    if (faculty) filters.push(eq(timetableTable.facultyId, faculty.id));
  }

  const rows = await db.select({
    id: timetableTable.id, classId: timetableTable.classId, subjectId: timetableTable.subjectId,
    facultyId: timetableTable.facultyId, day: timetableTable.day,
    startTime: timetableTable.startTime, endTime: timetableTable.endTime,
    subjectName: subjectsTable.name, facultyName: usersTable.name,
    classBranch: classesTable.branch, classSemester: classesTable.semester, classSection: classesTable.section,
  }).from(timetableTable)
    .leftJoin(classesTable, eq(timetableTable.classId, classesTable.id))
    .leftJoin(subjectsTable, eq(timetableTable.subjectId, subjectsTable.id))
    .leftJoin(facultyTable, eq(timetableTable.facultyId, facultyTable.id))
    .leftJoin(usersTable, eq(facultyTable.userId, usersTable.id))
    .where(filters.length > 0 ? and(...filters) : undefined)
    .orderBy(timetableTable.day, timetableTable.startTime);

  res.json(rows.map(r => ({
    id: r.id, classId: r.classId, subjectId: r.subjectId, facultyId: r.facultyId,
    day: r.day, startTime: r.startTime, endTime: r.endTime,
    subjectName: r.subjectName, facultyName: r.facultyName,
    className: r.classBranch ? `${r.classBranch} Sem ${r.classSemester} Sec ${r.classSection}` : null,
  })));
});

router.post("/timetable", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const parsed = CreateTimetableEntryBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [entry] = await db.insert(timetableTable).values({
    ...parsed.data,
    facultyId: parsed.data.facultyId ?? null,
    day: parsed.data.day as "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday",
  }).returning();
  res.status(201).json({ ...entry, className: null, subjectName: null, facultyName: null });
});

router.patch("/timetable/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = UpdateTimetableEntryParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateTimetableEntryBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const updateData: Partial<typeof timetableTable.$inferInsert> = {};
  if (parsed.data.subjectId) updateData.subjectId = parsed.data.subjectId;
  if (parsed.data.facultyId !== undefined) updateData.facultyId = parsed.data.facultyId;
  if (parsed.data.day) updateData.day = parsed.data.day as "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday";
  if (parsed.data.startTime) updateData.startTime = parsed.data.startTime;
  if (parsed.data.endTime) updateData.endTime = parsed.data.endTime;
  const [entry] = await db.update(timetableTable).set(updateData).where(eq(timetableTable.id, params.data.id)).returning();
  if (!entry) { res.status(404).json({ error: "Timetable entry not found" }); return; }
  res.json({ ...entry, className: null, subjectName: null, facultyName: null });
});

router.delete("/timetable/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = DeleteTimetableEntryParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [entry] = await db.delete(timetableTable).where(eq(timetableTable.id, params.data.id)).returning();
  if (!entry) { res.status(404).json({ error: "Entry not found" }); return; }
  res.sendStatus(204);
});

export default router;
