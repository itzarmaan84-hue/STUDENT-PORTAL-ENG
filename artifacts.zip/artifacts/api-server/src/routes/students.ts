import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { usersTable, studentsTable } from "@workspace/db";
import { eq, ilike, and, SQL } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";
import {
  ListStudentsQueryParams,
  CreateStudentBody,
  GetStudentParams,
  UpdateStudentParams,
  UpdateStudentBody,
  DeleteStudentParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/students", requireAuth, async (req, res): Promise<void> => {
  const params = ListStudentsQueryParams.safeParse(req.query);
  const filters: SQL[] = [];
  if (params.success) {
    if (params.data.branch) filters.push(ilike(studentsTable.branch, `%${params.data.branch}%`));
    if (params.data.semester) filters.push(eq(studentsTable.semester, params.data.semester));
    if (params.data.section) filters.push(eq(studentsTable.section, params.data.section));
  }

  const rows = await db
    .select({
      id: studentsTable.id,
      userId: studentsTable.userId,
      branch: studentsTable.branch,
      semester: studentsTable.semester,
      section: studentsTable.section,
      rollNumber: studentsTable.rollNumber,
      createdAt: studentsTable.createdAt,
      name: usersTable.name,
      email: usersTable.email,
      phone: usersTable.phone,
      profilePhoto: usersTable.profilePhoto,
    })
    .from(studentsTable)
    .innerJoin(usersTable, eq(studentsTable.userId, usersTable.id))
    .where(filters.length > 0 ? and(...filters) : undefined);

  if (params.success && params.data.search) {
    const s = params.data.search.toLowerCase();
    res.json(rows.filter(r => r.name.toLowerCase().includes(s) || r.email.toLowerCase().includes(s) || r.rollNumber.toLowerCase().includes(s)));
    return;
  }
  res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/students", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const parsed = CreateStudentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { name, email, password, phone, branch, semester, section, rollNumber } = parsed.data;
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email.toLowerCase()));
  if (existing.length > 0) {
    res.status(400).json({ error: "Email already in use" });
    return;
  }
  const hashed = await bcrypt.hash(password, 10);
  const [user] = await db.insert(usersTable).values({ name, email: email.toLowerCase(), password: hashed, phone, role: "student" }).returning();
  const [student] = await db.insert(studentsTable).values({ userId: user.id, branch, semester, section, rollNumber }).returning();
  res.status(201).json({ ...student, name: user.name, email: user.email, phone: user.phone, profilePhoto: user.profilePhoto, createdAt: student.createdAt.toISOString() });
});

router.get("/students/:id", requireAuth, async (req, res): Promise<void> => {
  const params = GetStudentParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [row] = await db.select({
    id: studentsTable.id, userId: studentsTable.userId, branch: studentsTable.branch,
    semester: studentsTable.semester, section: studentsTable.section, rollNumber: studentsTable.rollNumber,
    createdAt: studentsTable.createdAt, name: usersTable.name, email: usersTable.email,
    phone: usersTable.phone, profilePhoto: usersTable.profilePhoto,
  }).from(studentsTable).innerJoin(usersTable, eq(studentsTable.userId, usersTable.id)).where(eq(studentsTable.id, params.data.id));
  if (!row) { res.status(404).json({ error: "Student not found" }); return; }
  res.json({ ...row, createdAt: row.createdAt.toISOString() });
});

router.patch("/students/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = UpdateStudentParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateStudentBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { name, phone, ...studentFields } = parsed.data;
  const [student] = await db.select().from(studentsTable).where(eq(studentsTable.id, params.data.id));
  if (!student) { res.status(404).json({ error: "Student not found" }); return; }
  if (name || phone) await db.update(usersTable).set({ ...(name ? { name } : {}), ...(phone ? { phone } : {}) }).where(eq(usersTable.id, student.userId));
  if (Object.keys(studentFields).length > 0) await db.update(studentsTable).set(studentFields).where(eq(studentsTable.id, params.data.id));
  const [updated] = await db.select({
    id: studentsTable.id, userId: studentsTable.userId, branch: studentsTable.branch,
    semester: studentsTable.semester, section: studentsTable.section, rollNumber: studentsTable.rollNumber,
    createdAt: studentsTable.createdAt, name: usersTable.name, email: usersTable.email,
    phone: usersTable.phone, profilePhoto: usersTable.profilePhoto,
  }).from(studentsTable).innerJoin(usersTable, eq(studentsTable.userId, usersTable.id)).where(eq(studentsTable.id, params.data.id));
  res.json({ ...updated, createdAt: updated.createdAt.toISOString() });
});

router.delete("/students/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = DeleteStudentParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [student] = await db.select().from(studentsTable).where(eq(studentsTable.id, params.data.id));
  if (!student) { res.status(404).json({ error: "Student not found" }); return; }
  await db.delete(usersTable).where(eq(usersTable.id, student.userId));
  res.sendStatus(204);
});

export default router;
