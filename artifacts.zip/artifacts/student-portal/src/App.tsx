import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { Layout } from "@/components/layout";

import LoginPage from "@/pages/login";
import RegisterPage from "@/pages/register";
import ForgotPasswordPage from "@/pages/forgot-password";

import StudentDashboard from "@/pages/student/dashboard";
import StudentAttendance from "@/pages/student/attendance";
import StudentAssignments from "@/pages/student/assignments";
import StudentTimetable from "@/pages/student/timetable";
import StudentMarks from "@/pages/student/marks";
import StudentNotices from "@/pages/student/notices";
import StudentAnnouncements from "@/pages/student/announcements";
import ProfilePage from "@/pages/profile";

import FacultyDashboard from "@/pages/faculty/dashboard";
import FacultyAttendance from "@/pages/faculty/attendance";
import FacultyAssignments from "@/pages/faculty/assignments";
import FacultyMarks from "@/pages/faculty/marks";

import AdminDashboard from "@/pages/admin/dashboard";
import AdminStudents from "@/pages/admin/students";
import AdminFaculty from "@/pages/admin/faculty";
import AdminDepartments from "@/pages/admin/departments";
import AdminSubjects from "@/pages/admin/subjects";
import AdminClasses from "@/pages/admin/classes";
import AdminNotices from "@/pages/admin/notices";
import AdminAnnouncements from "@/pages/admin/announcements";
import AdminTimetable from "@/pages/admin/timetable";
import AdminMarks from "@/pages/admin/marks";

import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30000 } },
});

function ProtectedRoute({ children, roles }: { children: React.ReactNode; roles?: string[] }) {
  const { user, isLoading } = useAuth();
  if (isLoading) return <div className="flex items-center justify-center h-screen"><div className="text-muted-foreground">Loading...</div></div>;
  if (!user) return <Redirect to="/login" />;
  if (roles && !roles.includes(user.role)) return <Redirect to="/login" />;
  return <Layout>{children}</Layout>;
}

function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  if (isLoading) return <div className="flex items-center justify-center h-screen"><div className="text-muted-foreground">Loading...</div></div>;
  if (user) {
    if (user.role === "admin") return <Redirect to="/admin/dashboard" />;
    if (user.role === "faculty") return <Redirect to="/faculty/dashboard" />;
    return <Redirect to="/dashboard" />;
  }
  return <>{children}</>;
}

function Router() {
  return (
    <Switch>
      <Route path="/login"><PublicRoute><LoginPage /></PublicRoute></Route>
      <Route path="/register"><PublicRoute><RegisterPage /></PublicRoute></Route>
      <Route path="/forgot-password"><PublicRoute><ForgotPasswordPage /></PublicRoute></Route>

      {/* Student */}
      <Route path="/dashboard"><ProtectedRoute roles={["student"]}><StudentDashboard /></ProtectedRoute></Route>
      <Route path="/attendance"><ProtectedRoute roles={["student"]}><StudentAttendance /></ProtectedRoute></Route>
      <Route path="/assignments"><ProtectedRoute roles={["student"]}><StudentAssignments /></ProtectedRoute></Route>
      <Route path="/timetable"><ProtectedRoute roles={["student"]}><StudentTimetable /></ProtectedRoute></Route>
      <Route path="/marks"><ProtectedRoute roles={["student"]}><StudentMarks /></ProtectedRoute></Route>
      <Route path="/notices"><ProtectedRoute roles={["student"]}><StudentNotices /></ProtectedRoute></Route>
      <Route path="/announcements"><ProtectedRoute roles={["student"]}><StudentAnnouncements /></ProtectedRoute></Route>
      <Route path="/profile"><ProtectedRoute><ProfilePage /></ProtectedRoute></Route>

      {/* Faculty */}
      <Route path="/faculty/dashboard"><ProtectedRoute roles={["faculty"]}><FacultyDashboard /></ProtectedRoute></Route>
      <Route path="/faculty/attendance"><ProtectedRoute roles={["faculty"]}><FacultyAttendance /></ProtectedRoute></Route>
      <Route path="/faculty/assignments"><ProtectedRoute roles={["faculty"]}><FacultyAssignments /></ProtectedRoute></Route>
      <Route path="/faculty/marks"><ProtectedRoute roles={["faculty"]}><FacultyMarks /></ProtectedRoute></Route>

      {/* Admin */}
      <Route path="/admin/dashboard"><ProtectedRoute roles={["admin"]}><AdminDashboard /></ProtectedRoute></Route>
      <Route path="/admin/students"><ProtectedRoute roles={["admin"]}><AdminStudents /></ProtectedRoute></Route>
      <Route path="/admin/faculty"><ProtectedRoute roles={["admin"]}><AdminFaculty /></ProtectedRoute></Route>
      <Route path="/admin/departments"><ProtectedRoute roles={["admin"]}><AdminDepartments /></ProtectedRoute></Route>
      <Route path="/admin/subjects"><ProtectedRoute roles={["admin"]}><AdminSubjects /></ProtectedRoute></Route>
      <Route path="/admin/classes"><ProtectedRoute roles={["admin"]}><AdminClasses /></ProtectedRoute></Route>
      <Route path="/admin/notices"><ProtectedRoute roles={["admin"]}><AdminNotices /></ProtectedRoute></Route>
      <Route path="/admin/announcements"><ProtectedRoute roles={["admin"]}><AdminAnnouncements /></ProtectedRoute></Route>
      <Route path="/admin/timetable"><ProtectedRoute roles={["admin"]}><AdminTimetable /></ProtectedRoute></Route>
      <Route path="/admin/marks"><ProtectedRoute roles={["admin"]}><AdminMarks /></ProtectedRoute></Route>

      <Route path="/"><PublicRoute><LoginPage /></PublicRoute></Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <Router />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
