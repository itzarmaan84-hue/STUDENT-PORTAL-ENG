import { useGetFacultySummary, useGetRecentActivity, getGetFacultySummaryQueryKey, getGetRecentActivityQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, FileText, CalendarCheck2, BookOpen, TrendingUp } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

function StatCard({ title, value, icon: Icon, sub }: { title: string; value: string | number; icon: React.ElementType; sub?: string }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold mt-1" data-testid={`stat-${title.toLowerCase().replace(/\s+/g, "-")}`}>{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
          </div>
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Icon className="w-5 h-5 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function FacultyDashboard() {
  const { user } = useAuth();
  const { data: summary, isLoading } = useGetFacultySummary({ query: { queryKey: getGetFacultySummaryQueryKey() } });
  const { data: activity } = useGetRecentActivity({ query: { queryKey: getGetRecentActivityQueryKey() } });

  return (
    <div className="p-8" data-testid="page-faculty-dashboard">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Welcome, {user?.name?.split(" ")[0]}</h1>
        <p className="text-muted-foreground text-sm">Faculty dashboard — your teaching overview</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          <StatCard title="Assigned Classes" value={summary?.assignedClasses ?? 0} icon={BookOpen} />
          <StatCard title="Total Students" value={summary?.totalStudents ?? 0} icon={Users} />
          <StatCard title="Assignments Created" value={summary?.assignmentsCreated ?? 0} icon={FileText} />
          <StatCard title="Pending Submissions" value={summary?.pendingSubmissions ?? 0} icon={FileText} sub="Awaiting review" />
          <StatCard title="Avg Attendance" value={`${summary?.averageAttendance ?? 0}%`} icon={CalendarCheck2} />
        </div>
      )}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          {activity && activity.length > 0 ? (
            <div className="space-y-3">
              {activity.slice(0, 8).map(a => (
                <div key={a.id} className="flex items-start gap-3 text-sm" data-testid={`activity-item-${a.id}`}>
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                  <div>
                    <span>{a.message}</span>
                    {a.actor && <span className="text-muted-foreground"> by {a.actor}</span>}
                    <p className="text-xs text-muted-foreground mt-0.5">{new Date(a.createdAt).toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">No recent activity</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
