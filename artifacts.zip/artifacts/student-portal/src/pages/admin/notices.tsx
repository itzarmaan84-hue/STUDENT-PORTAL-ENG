import { useState } from "react";
import { useListNotices, useCreateNotice, useDeleteNotice, getListNoticesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2 } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

const schema = z.object({ title: z.string().min(2), description: z.string().min(5), attachment: z.string().optional() });

export default function AdminNotices() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const { data: notices, isLoading } = useListNotices({ query: { queryKey: getListNoticesQueryKey() } });
  const createMutation = useCreateNotice();
  const deleteMutation = useDeleteNotice();

  const form = useForm({ resolver: zodResolver(schema), defaultValues: { title: "", description: "", attachment: "" } });

  const onSubmit = (data: z.infer<typeof schema>) => {
    createMutation.mutate({ data: { title: data.title, description: data.description, attachment: data.attachment || undefined } }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListNoticesQueryKey() }); toast({ title: "Notice created" }); setOpen(false); form.reset(); },
      onError: (e) => toast({ title: "Failed", description: e instanceof Error ? e.message : undefined, variant: "destructive" }),
    });
  };

  const handleDelete = () => {
    if (!deleteId) return;
    deleteMutation.mutate({ id: deleteId }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListNoticesQueryKey() }); toast({ title: "Deleted" }); setDeleteId(null); },
      onError: () => toast({ title: "Delete failed", variant: "destructive" }),
    });
  };

  return (
    <div className="p-8" data-testid="page-admin-notices">
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="text-2xl font-bold">Notices</h1><p className="text-muted-foreground text-sm">Create and manage official notices</p></div>
        <Button onClick={() => setOpen(true)} data-testid="button-add-notice"><Plus className="w-4 h-4 mr-1" />Post Notice</Button>
      </div>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader><TableRow><TableHead>Title</TableHead><TableHead>Description</TableHead><TableHead>Date</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">Loading...</TableCell></TableRow>
              ) : notices && notices.length > 0 ? [...notices].reverse().map(n => (
                <TableRow key={n.id} data-testid={`notice-row-${n.id}`}>
                  <TableCell className="font-medium">{n.title}</TableCell>
                  <TableCell className="text-muted-foreground text-sm max-w-xs truncate">{n.description}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{new Date(n.createdAt).toLocaleDateString()}</TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="ghost" onClick={() => setDeleteId(n.id)} data-testid={`button-delete-${n.id}`}><Trash2 className="w-3.5 h-3.5" /></Button>
                  </TableCell>
                </TableRow>
              )) : (
                <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No notices yet</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Post Notice</DialogTitle></DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField control={form.control} name="title" render={({ field }) => (<FormItem><FormLabel>Title</FormLabel><FormControl><Input data-testid="input-title" {...field} /></FormControl><FormMessage /></FormItem>)} />
              <FormField control={form.control} name="description" render={({ field }) => (<FormItem><FormLabel>Description</FormLabel><FormControl><Textarea data-testid="input-description" rows={4} {...field} /></FormControl><FormMessage /></FormItem>)} />
              <FormField control={form.control} name="attachment" render={({ field }) => (<FormItem><FormLabel>Attachment URL (optional)</FormLabel><FormControl><Input placeholder="https://..." {...field} /></FormControl><FormMessage /></FormItem>)} />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button type="submit" data-testid="button-confirm-post" disabled={createMutation.isPending}>{createMutation.isPending ? "Posting..." : "Post Notice"}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={v => !v && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete notice?</AlertDialogTitle><AlertDialogDescription>This notice will be removed for all students.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
