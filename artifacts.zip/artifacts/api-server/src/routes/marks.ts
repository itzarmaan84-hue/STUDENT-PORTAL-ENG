import { Router } from "express";
import { db } from "@workspace/db";
import { marksTable, studentsTable, subjectsTable, usersTable } from "@workspace/db";
import { eq, and, SQL } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";
import { ListMarksQueryParams, CreateMarkBody, UpdateMarkParams, UpdateMarkBody } from "@workspace/api-zod";

const router = Router();

router.get("/marks", requireAuth, async (req, res): Promise<void> => {
  const params = ListMarksQueryParams.safeParse(req.query);
  const filters: SQL[] = [];
  if (params.success) {
    if (params.data.studentId) filters.push(eq(marksTable.studentId, params.data.studentId));
    if (params.data.subjectId) filters.push(eq(marksTable.subjectId, params.data.subjectId));
  }

  if (req.user?.role === "student") {
    const [student] = await db.select().from(studentsTable).where(eq(studentsTable.userId, req.user.userId));
    if (student) filters.push(eq(marksTable.studentId, student.id));
  }

  const rows = await db.select({
    id: marksTable.id, studentId: marksTable.studentId, subjectId: marksTable.subjectId,
    internal1: marksTable.internal1, internal2: marksTable.internal2, assignmentMarks: marksTable.assignmentMarks,
    studentName: usersTable.name, subjectName: subjectsTable.name,
  }).from(marksTable)
    .leftJoin(studentsTable, eq(marksTable.studentId, studentsTable.id))
    .leftJoin(usersTable, eq(studentsTable.userId, usersTable.id))
    .leftJoin(subjectsTable, eq(marksTable.subjectId, subjectsTable.id))
    .where(filters.length > 0 ? and(...filters) : undefined);

  res.json(rows.map(r => ({
    ...r,
    total: r.internal1 != null && r.internal2 != null
      ? Math.round(((r.internal1 + r.internal2) / 2) + (r.assignmentMarks ?? 0))
      : null,
  })));
});

router.post("/marks", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateMarkBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [mark] = await db.insert(marksTable).values({
    studentId: parsed.data.studentId,
    subjectId: parsed.data.subjectId,
    internal1: parsed.data.internal1 ?? null,
    internal2: parsed.data.internal2 ?? null,
    assignmentMarks: parsed.data.assignmentMarks ?? null,
  }).returning();
  res.status(201).json({ ...mark, studentName: null, subjectName: null, total: null });
});

router.patch("/marks/:id", requireAuth, async (req, res): Promise<void> => {
  const params = UpdateMarkParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateMarkBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [mark] = await db.update(marksTable).set(parsed.data).where(eq(marksTable.id, params.data.id)).returning();
  if (!mark) { res.status(404).json({ error: "Mark record not found" }); return; }
  res.json({ ...mark, studentName: null, subjectName: null, total: null });
});

export default router;
