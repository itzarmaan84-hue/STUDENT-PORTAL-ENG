import { useState } from "react";
import { useListMarks, useListStudents, useListSubjects, useCreateMark, useUpdateMark, getListMarksQueryKey, getListStudentsQueryKey, getListSubjectsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";

export default function AdminMarks() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [subjectId, setSubjectId] = useState<string>("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editValues, setEditValues] = useState({ internal1: "", internal2: "", assignmentMarks: "" });

  const { data: students } = useListStudents({}, { query: { queryKey: getListStudentsQueryKey({}) } });
  const { data: subjects } = useListSubjects({}, { query: { queryKey: getListSubjectsQueryKey({}) } });
  const { data: marks } = useListMarks(subjectId ? { subjectId: parseInt(subjectId) } : {}, {
    query: { queryKey: getListMarksQueryKey(subjectId ? { subjectId: parseInt(subjectId) } : {}) }
  });
  const createMutation = useCreateMark();
  const updateMutation = useUpdateMark();

  const getMarkForStudent = (studentId: number) => marks?.find(m => m.studentId === studentId);

  const handleSave = (studentId: number) => {
    const existing = getMarkForStudent(studentId);
    const data = {
      internal1: editValues.internal1 ? parseFloat(editValues.internal1) : undefined,
      internal2: editValues.internal2 ? parseFloat(editValues.internal2) : undefined,
      assignmentMarks: editValues.assignmentMarks ? parseFloat(editValues.assignmentMarks) : undefined,
    };
    if (existing) {
      updateMutation.mutate({ id: existing.id, data }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListMarksQueryKey({}) }); setEditingId(null); toast({ title: "Updated" }); },
        onError: () => toast({ title: "Failed", variant: "destructive" }),
      });
    } else {
      createMutation.mutate({ data: { studentId, subjectId: parseInt(subjectId), ...data } }, {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListMarksQueryKey({}) }); setEditingId(null); toast({ title: "Saved" }); },
        onError: () => toast({ title: "Failed", variant: "destructive" }),
      });
    }
  };

  const startEdit = (studentId: number) => {
    const existing = getMarkForStudent(studentId);
    setEditValues({
      internal1: existing?.internal1 != null ? String(existing.internal1) : "",
      internal2: existing?.internal2 != null ? String(existing.internal2) : "",
      assignmentMarks: existing?.assignmentMarks != null ? String(existing.assignmentMarks) : "",
    });
    setEditingId(studentId);
  };

  return (
    <div className="p-8" data-testid="page-admin-marks">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Marks</h1>
        <p className="text-muted-foreground text-sm">View and enter marks for all students</p>
      </div>

      <Card className="mb-6">
        <CardContent className="pt-5">
          <div className="max-w-xs">
            <label className="text-sm font-medium block mb-1.5">Select Subject</label>
            <Select value={subjectId} onValueChange={setSubjectId}>
              <SelectTrigger data-testid="select-subject"><SelectValue placeholder="Choose a subject" /></SelectTrigger>
              <SelectContent>
                {subjects?.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {subjectId && students && (
        <Card>
          <CardHeader><CardTitle className="text-base">Student Marks</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Roll No.</TableHead>
                  <TableHead>Student</TableHead>
                  <TableHead className="text-right">Internal 1 /30</TableHead>
                  <TableHead className="text-right">Internal 2 /30</TableHead>
                  <TableHead className="text-right">Assignment /20</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students.map(s => {
                  const mark = getMarkForStudent(s.id);
                  const isEditing = editingId === s.id;
                  const total = mark ? Math.round(((mark.internal1 ?? 0) + (mark.internal2 ?? 0)) / 2 + (mark.assignmentMarks ?? 0)) : null;
                  return (
                    <TableRow key={s.id} data-testid={`marks-row-${s.id}`}>
                      <TableCell className="font-mono text-sm">{s.rollNumber}</TableCell>
                      <TableCell className="font-medium">{s.name}</TableCell>
                      {isEditing ? (
                        <>
                          <TableCell><Input type="number" min={0} max={30} className="w-20 h-7 text-right" value={editValues.internal1} onChange={e => setEditValues(p => ({ ...p, internal1: e.target.value }))} /></TableCell>
                          <TableCell><Input type="number" min={0} max={30} className="w-20 h-7 text-right" value={editValues.internal2} onChange={e => setEditValues(p => ({ ...p, internal2: e.target.value }))} /></TableCell>
                          <TableCell><Input type="number" min={0} max={20} className="w-20 h-7 text-right" value={editValues.assignmentMarks} onChange={e => setEditValues(p => ({ ...p, assignmentMarks: e.target.value }))} /></TableCell>
                          <TableCell className="text-right text-muted-foreground">—</TableCell>
                          <TableCell className="text-right">
                            <Button size="sm" onClick={() => handleSave(s.id)}>Save</Button>
                          </TableCell>
                        </>
                      ) : (
                        <>
                          <TableCell className="text-right">{mark?.internal1 ?? "—"}</TableCell>
                          <TableCell className="text-right">{mark?.internal2 ?? "—"}</TableCell>
                          <TableCell className="text-right">{mark?.assignmentMarks ?? "—"}</TableCell>
                          <TableCell className="text-right font-semibold">{total ?? "—"}</TableCell>
                          <TableCell className="text-right">
                            <Button size="sm" variant="outline" onClick={() => startEdit(s.id)} data-testid={`button-edit-${s.id}`}>
                              {mark ? "Edit" : "Add"}
                            </Button>
                          </TableCell>
                        </>
                      )}
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
