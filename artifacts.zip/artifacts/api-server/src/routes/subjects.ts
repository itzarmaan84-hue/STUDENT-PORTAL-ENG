import { Router } from "express";
import { db } from "@workspace/db";
import { subjectsTable, departmentsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireRole } from "../middlewares/auth";
import { ListSubjectsQueryParams, CreateSubjectBody, UpdateSubjectParams, UpdateSubjectBody, DeleteSubjectParams } from "@workspace/api-zod";

const router = Router();

router.get("/subjects", requireAuth, async (req, res): Promise<void> => {
  const params = ListSubjectsQueryParams.safeParse(req.query);
  const rows = await db.select({
    id: subjectsTable.id, name: subjectsTable.name, code: subjectsTable.code,
    departmentId: subjectsTable.departmentId, createdAt: subjectsTable.createdAt,
    departmentName: departmentsTable.name,
  }).from(subjectsTable).leftJoin(departmentsTable, eq(subjectsTable.departmentId, departmentsTable.id));

  const filtered = (params.success && params.data.departmentId)
    ? rows.filter(r => r.departmentId === params.data.departmentId)
    : rows;
  res.json(filtered.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/subjects", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const parsed = CreateSubjectBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [subj] = await db.insert(subjectsTable).values(parsed.data).returning();
  res.status(201).json({ ...subj, createdAt: subj.createdAt.toISOString(), departmentName: null });
});

router.patch("/subjects/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = UpdateSubjectParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateSubjectBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [subj] = await db.update(subjectsTable).set(parsed.data).where(eq(subjectsTable.id, params.data.id)).returning();
  if (!subj) { res.status(404).json({ error: "Subject not found" }); return; }
  res.json({ ...subj, createdAt: subj.createdAt.toISOString(), departmentName: null });
});

router.delete("/subjects/:id", requireAuth, requireRole("admin"), async (req, res): Promise<void> => {
  const params = DeleteSubjectParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [subj] = await db.delete(subjectsTable).where(eq(subjectsTable.id, params.data.id)).returning();
  if (!subj) { res.status(404).json({ error: "Subject not found" }); return; }
  res.sendStatus(204);
});

export default router;
