import { Router } from "express";
import { db } from "@workspace/db";
import { announcementsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";
import { CreateAnnouncementBody, UpdateAnnouncementParams, UpdateAnnouncementBody, DeleteAnnouncementParams } from "@workspace/api-zod";

const router = Router();

router.get("/announcements", requireAuth, async (_req, res): Promise<void> => {
  const rows = await db.select({
    id: announcementsTable.id, title: announcementsTable.title,
    description: announcementsTable.description, priority: announcementsTable.priority,
    createdAt: announcementsTable.createdAt, authorId: announcementsTable.authorId,
    authorName: usersTable.name,
  }).from(announcementsTable)
    .leftJoin(usersTable, eq(announcementsTable.authorId, usersTable.id))
    .orderBy(announcementsTable.createdAt);
  res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/announcements", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateAnnouncementBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [ann] = await db.insert(announcementsTable).values({
    ...parsed.data,
    authorId: req.user!.userId,
    priority: parsed.data.priority as "low" | "medium" | "high",
  }).returning();
  res.status(201).json({ ...ann, createdAt: ann.createdAt.toISOString(), authorName: null });
});

router.patch("/announcements/:id", requireAuth, async (req, res): Promise<void> => {
  const params = UpdateAnnouncementParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateAnnouncementBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const updateData: Partial<typeof announcementsTable.$inferInsert> = {};
  if (parsed.data.title) updateData.title = parsed.data.title;
  if (parsed.data.description) updateData.description = parsed.data.description;
  if (parsed.data.priority) updateData.priority = parsed.data.priority as "low" | "medium" | "high";
  const [ann] = await db.update(announcementsTable).set(updateData).where(eq(announcementsTable.id, params.data.id)).returning();
  if (!ann) { res.status(404).json({ error: "Announcement not found" }); return; }
  res.json({ ...ann, createdAt: ann.createdAt.toISOString(), authorName: null });
});

router.delete("/announcements/:id", requireAuth, async (req, res): Promise<void> => {
  const params = DeleteAnnouncementParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const [ann] = await db.delete(announcementsTable).where(eq(announcementsTable.id, params.data.id)).returning();
  if (!ann) { res.status(404).json({ error: "Announcement not found" }); return; }
  res.sendStatus(204);
});

export default router;
